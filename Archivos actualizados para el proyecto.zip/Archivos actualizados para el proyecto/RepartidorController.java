package com.deliveryapp.delivery_backend.controller;

import com.deliveryapp.delivery_backend.model.Pedido;
import com.deliveryapp.delivery_backend.model.Repartidor;
import com.deliveryapp.delivery_backend.repository.PedidoRepository;
import com.deliveryapp.delivery_backend.repository.UsuarioRepository;
import com.deliveryapp.delivery_backend.service.UsuarioService;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;



@RestController
@RequestMapping("/api/repartidores")
public class RepartidorController {

    @Autowired
    private UsuarioRepository usuarioRepository;
    
    @Autowired
    private PedidoRepository pedidoRepository;

    @GetMapping
    public List<Repartidor> listarRepartidores() {
        // Filtra todos los usuarios y devuelve solo los que son Repartidores
        return usuarioRepository.findAll().stream()
                .filter(u -> u instanceof Repartidor)
                .map(u -> (Repartidor) u)
                .collect(Collectors.toList());
    }
    
        @GetMapping("/todos")
    public List<Pedido> listarTodos() {
        // Esto debería devolver TODOS los pedidos de la base de datos
        return pedidoRepository.findAll();
    }
}
