package com.deliveryapp.delivery_backend.model;

import jakarta.persistence.DiscriminatorValue;
import lombok.Data;

@Data
public class LoginResponse {
    private Long id;
    private String nombre;
    private String email;
    private String rol;
    
    // Campos específicos según el rol
    private String direccionFavorita; // Para Cliente
    private String nombreComercial;   // Para Restaurante
    private String vehiculo;          // Para Repartidor

    public LoginResponse(Usuario user) {
        this.id = user.getId();
        this.nombre = user.getNombre();
        this.email = user.getEmail();
        
        // Obtenemos el rol usando la anotación @DiscriminatorValue de JPA
        DiscriminatorValue dv = user.getClass().getAnnotation(DiscriminatorValue.class);
        this.rol = (dv != null) ? dv.value() : "CLIENTE";

        if (user instanceof Cliente c) {
            this.direccionFavorita = c.getDireccionFavorita();
        } else if (user instanceof Restaurante r) {
            this.nombreComercial = r.getNombreComercial();
        } else if (user instanceof Repartidor rep) {
            this.vehiculo = rep.getVehiculo();
        }
    }
}