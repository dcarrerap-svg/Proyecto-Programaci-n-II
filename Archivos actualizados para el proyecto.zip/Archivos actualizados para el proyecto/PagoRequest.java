package com.deliveryapp.delivery_backend.model;

import lombok.Data;

@Data
public class PagoRequest {
    private Long pedidoId;
    private String metodoPago; // "TARJETA" o "EFECTIVO"
    
    // Solo si es tarjeta (datos falsos)
    private String numeroTarjeta;
    private String fechaExpiracion;
    private String cvv;
}
