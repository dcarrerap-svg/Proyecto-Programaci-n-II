package com.deliveryapp.delivery_backend.controller;

import com.deliveryapp.delivery_backend.model.PagoRequest;
import com.deliveryapp.delivery_backend.model.Pedido;
import com.deliveryapp.delivery_backend.repository.PedidoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/pagos")
public class PagoController {

    @Autowired
    private PedidoRepository pedidoRepository;

    @PostMapping("/procesar")
    public ResponseEntity<?> procesarPago(@RequestBody PagoRequest request) {
        Pedido pedido = pedidoRepository.findById(request.getPedidoId()).orElse(null);

        if (pedido == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "Pedido no encontrado"));
        }

        if (pedido.isPagado()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Este pedido ya fue pagado"));
        }

        // Validación básica simulada
        if ("TARJETA".equals(request.getMetodoPago())) {
            if (request.getNumeroTarjeta() == null || request.getNumeroTarjeta().length() < 16) {
                return ResponseEntity.badRequest().body(Map.of("error", "Número de tarjeta inválido"));
            }
            // Aquí en un sistema real se conectaría con un banco
        }

        // Marcar como pagado
        pedido.setMetodoPago(request.getMetodoPago());
        pedido.setPagado(true);
        pedidoRepository.save(pedido);

        return ResponseEntity.ok(Map.of(
            "mensaje", "Pago procesado con éxito",
            "metodo", pedido.getMetodoPago(),
            "pedidoId", pedido.getId()
        ));
    }
}
