package com.deliveryapp.delivery_backend.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@DiscriminatorValue("RESTAURANTE")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class Restaurante extends Usuario {

    private String nombreComercial;
    private String direccion;
    private boolean activo = true;
    
    private Double latitud = 14.6349; // Coordenada por defecto (Guatemala)
    private Double longitud = -90.5069;
    
    

    @Override
    public String obtenerPanel() {
        return "Panel de Restaurante: gestionar menú, ver pedidos entrantes";
    }
}