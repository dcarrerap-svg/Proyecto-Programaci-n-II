package com.pideya.app.model;

public class Pedido {
    private final int id, clienteId;
    private final String restaurante;
    private final double total;
    private EstadoPedido estado = EstadoPedido.PENDIENTE;
    private double latitud, longitud;
    private String clienteNombre = "";
    private int repartidorId, restauranteId, calificacionEstrellas;
    private String metodoPago = "EFECTIVO", detalle = "";
    private double costoEnvio;

    public Pedido(int id, int clienteId, String restaurante, double total) {
        this.id = id; this.clienteId = clienteId; this.restaurante = restaurante; this.total = total;
    }
    public Pedido(int id, int clienteId, String restaurante, double total, EstadoPedido estado) {
        this(id, clienteId, restaurante, total);
        this.estado = estado;
    }
    public void setEntrega(double latitud, double longitud, String clienteNombre) {
        this.latitud = latitud; this.longitud = longitud; this.clienteNombre = clienteNombre;
    }
    public double getLatitud() { return latitud; }
    public double getLongitud() { return longitud; }
    public String getClienteNombre() { return clienteNombre; }
    public int getRepartidorId() { return repartidorId; }
    public void setRepartidorId(int repartidorId) { this.repartidorId = repartidorId; }
    public void setPago(String metodoPago, double costoEnvio) { this.metodoPago = metodoPago; this.costoEnvio = costoEnvio; }
    public String getMetodoPago() { return metodoPago; }
    public double getCostoEnvio() { return costoEnvio; }
    public String getDetalle() { return detalle; }
    public void setDetalle(String detalle) { this.detalle = detalle; }
    public int getCalificacionEstrellas() { return calificacionEstrellas; }
    public void setCalificacionEstrellas(int n) { this.calificacionEstrellas = n; }
    public int getRestauranteId() { return restauranteId; }
    public void setRestauranteId(int id) { this.restauranteId = id; }
    public void setEstado(EstadoPedido e) { this.estado = e; }
    public int getId() { return id; }
    public int getClienteId() { return clienteId; }
    public String getRestaurante() { return restaurante; }
    public double getTotal() { return total; }
    public EstadoPedido getEstado() { return estado; }
    public void avanzar() { estado = estado.siguiente(); }

    @Override public String toString() {
        return "Pedido #" + id + " · " + restaurante + "\nQ" + String.format("%.2f", total) + " · " + estado;
    }
}
