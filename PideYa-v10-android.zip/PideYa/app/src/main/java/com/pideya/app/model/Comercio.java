package com.pideya.app.model;

import com.pideya.app.ui.PedidosComercioActivity;

public class Comercio extends Usuario {
    public Comercio(int id, String nombre, String email) { super(id, nombre, email, "restaurante"); }
    @Override public Class<?> pantallaInicial() { return PedidosComercioActivity.class; }
}
