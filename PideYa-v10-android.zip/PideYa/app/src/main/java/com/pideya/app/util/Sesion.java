package com.pideya.app.util;

import com.pideya.app.model.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

public class Sesion {
    public static Usuario usuario;
    /** Última ubicación obtenida con Google Play Services */
    public static double latitud, longitud;
    public static boolean ubicacionReal;
    public static Restaurante restaurante;
    public static final List<Producto> carrito = new ArrayList<>();
    /** pedidoId -> estrellas dadas en esta sesión (el backend aún no informa qué pedidos ya se calificaron) */
    public static final Map<Integer, Integer> calificaciones = new HashMap<>();
    /** pedidoId -> método de pago y envío / código de entrega (solo de esta sesión; el backend aún no los guarda) */
    public static final Map<Integer, String> pagos = new HashMap<>(), codigos = new HashMap<>();

    public static void cerrar() {
        usuario = null;
        restaurante = null;
        carrito.clear();
        calificaciones.clear();
        pagos.clear();
        codigos.clear();
    }
}
