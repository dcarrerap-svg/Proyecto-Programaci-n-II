package com.pideya.app.data;

/** Único punto para elegir de dónde salen los datos. */
public class Repo {
    /** true = backend real (Spring Boot encendido); false = datos de prueba sin internet. */
    private static final boolean USAR_BACKEND = true;

    private static final DeliveryRepository INSTANCIA =
            USAR_BACKEND ? new ApiRepository() : new MockRepository();

    public static DeliveryRepository get() { return INSTANCIA; }
}
