package com.pideya.app.model;

public class Restaurante {
    private final int id, minutos;
    private final String nombre, direccion, emoji, categoria;
    private final double rating, latitud, longitud;

    public Restaurante(int id, String nombre, String direccion, String emoji, String categoria, double rating, int minutos) {
        this(id, nombre, direccion, emoji, categoria, rating, minutos, 0, 0);
    }
    public Restaurante(int id, String nombre, String direccion, String emoji, String categoria,
                       double rating, int minutos, double latitud, double longitud) {
        this.id = id; this.nombre = nombre; this.direccion = direccion; this.emoji = emoji;
        this.categoria = categoria; this.rating = rating; this.minutos = minutos;
        this.latitud = latitud; this.longitud = longitud;
    }
    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getDireccion() { return direccion; }
    public String getEmoji() { return emoji; }
    public String getCategoria() { return categoria; }
    public double getRating() { return rating; }
    public int getMinutos() { return minutos; }
    public double getLatitud() { return latitud; }
    public double getLongitud() { return longitud; }
    public boolean tieneUbicacion() { return latitud != 0 || longitud != 0; }
    /** Texto de calificación y tiempo; si el backend aún no los trae, muestra un texto neutro. */
    public String getMeta() { return rating > 0 ? "★ " + rating + "   ·   " + minutos + " min" : "Disponible ahora"; }
}
