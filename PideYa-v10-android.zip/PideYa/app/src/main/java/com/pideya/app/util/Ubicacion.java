package com.pideya.app.util;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import androidx.core.content.ContextCompat;

public class Ubicacion {
    public static boolean tienePermiso(Context c) {
        return ContextCompat.checkSelfPermission(c, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            || ContextCompat.checkSelfPermission(c, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    /** Devuelve {latitud, longitud, 1 si es real / 0 si es la ubicación por defecto (Ciudad de Guatemala)}. */
    public static double[] actual(Context c) {
        if (Sesion.ubicacionReal) return new double[]{Sesion.latitud, Sesion.longitud, 1};
        double[] porDefecto = {14.6349, -90.5069, 0};
        if (!tienePermiso(c)) return porDefecto;
        LocationManager lm = (LocationManager) c.getSystemService(Context.LOCATION_SERVICE);
        Location mejor = null;
        for (String proveedor : lm.getProviders(true)) {
            try {
                Location l = lm.getLastKnownLocation(proveedor);
                if (l != null && (mejor == null || l.getAccuracy() < mejor.getAccuracy())) mejor = l;
            } catch (SecurityException ignorado) { }
        }
        return mejor == null ? porDefecto : new double[]{mejor.getLatitude(), mejor.getLongitude(), 1};
    }

    /** Pide la ubicación a la API de Google (Fused Location Provider) y la guarda en la sesión. */
    public static void actualizar(Context c) {
        if (!tienePermiso(c)) return;
        try {
            com.google.android.gms.location.LocationServices.getFusedLocationProviderClient(c)
                .getCurrentLocation(com.google.android.gms.location.Priority.PRIORITY_BALANCED_POWER_ACCURACY, null)
                .addOnSuccessListener(l -> {
                    if (l != null) { Sesion.latitud = l.getLatitude(); Sesion.longitud = l.getLongitude(); Sesion.ubicacionReal = true; }
                });
        } catch (SecurityException ignorado) { }
    }
}
