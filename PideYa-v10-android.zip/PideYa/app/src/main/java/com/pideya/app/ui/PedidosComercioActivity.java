package com.pideya.app.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.pideya.app.R;
import com.pideya.app.data.Callback;
import com.pideya.app.data.Repo;
import com.pideya.app.model.EstadoPedido;
import com.pideya.app.model.Pedido;
import com.pideya.app.util.Sesion;
import com.pideya.app.util.Ui;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Pantalla del comercio: revisa los datos del pedido y decide si lo acepta o lo rechaza. */
public class PedidosComercioActivity extends AppCompatActivity {
    private final List<Pedido> datos = new ArrayList<>();
    private ListaAdapter<Pedido> ad;
    private RecyclerView rv;
    private TextView resumen, vacio;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_lista);
        Ui.insets(this, findViewById(R.id.header), findViewById(R.id.barra));
        ((TextView) findViewById(R.id.titulo)).setText("Pedidos del comercio");
        ((TextView) findViewById(R.id.subtitulo)).setText("Hola, " + Sesion.usuario.getNombre() + " 🍽️");
        resumen = findViewById(R.id.resumen);
        vacio = findViewById(R.id.vacio);
        vacio.setText("📭\nAún no hay pedidos");
        findViewById(R.id.tema).setVisibility(View.VISIBLE);
        findViewById(R.id.tema).setOnClickListener(v -> Ui.alternarTema(this));
        findViewById(R.id.salir).setVisibility(View.VISIBLE);
        findViewById(R.id.salir).setOnClickListener(v -> Ui.confirmarSalida(this));
        Button btn = findViewById(R.id.boton);
        btn.setText("Actualizar");
        btn.setOnClickListener(v -> cargar());

        rv = findViewById(R.id.lista);
        rv.setLayoutManager(new LinearLayoutManager(this));
        ad = new ListaAdapter<>(datos, R.layout.item_pedido, (v, p) -> {
            ((TextView) v.findViewById(R.id.numero)).setText("Pedido #" + p.getId());
            TextView chip = v.findViewById(R.id.estado);
            chip.setText(p.getEstado().etiqueta());
            chip.getBackground().mutate().setTint(p.getEstado().color());
            ((TextView) v.findViewById(R.id.restaurante)).setText("👤 " + p.getClienteNombre() + "\n" + p.getDetalle());
            ((TextView) v.findViewById(R.id.total)).setText("Total " + Ui.q(p.getTotal()));
            TextView pago = v.findViewById(R.id.pago);
            pago.setVisibility(View.VISIBLE);
            pago.setText(Ui.pago(p.getMetodoPago(), p.getCostoEnvio()));
            TextView ubic = v.findViewById(R.id.codigo);
            ubic.setVisibility(View.VISIBLE);
            ubic.setText(String.format(Locale.US, "📍 Entrega en %.5f, %.5f", p.getLatitud(), p.getLongitud()));
            v.findViewById(R.id.calificar).setVisibility(View.GONE);
            v.setOnClickListener(x -> acciones(p));
        });
        rv.setAdapter(ad);
    }

    @Override protected void onResume() { super.onResume(); cargar(); }

    private void cargar() {
        Repo.get().getPedidosComercio(Sesion.usuario.getId(), new Callback<List<Pedido>>() {
            @Override public void onOk(List<Pedido> l) {
                datos.clear(); datos.addAll(l);
                ad.notifyDataSetChanged(); rv.scheduleLayoutAnimation();
                int nuevos = 0;
                for (Pedido p : datos) if (p.getEstado() == EstadoPedido.PENDIENTE) nuevos++;
                resumen.setText(datos.size() + " pedidos · " + nuevos + " por aceptar");
                vacio.setVisibility(datos.isEmpty() ? View.VISIBLE : View.GONE);
            }
            @Override public void onError(String m) { Toast.makeText(PedidosComercioActivity.this, m, Toast.LENGTH_SHORT).show(); }
        });
    }

    private void acciones(Pedido p) {
        EstadoPedido[] destinos = {EstadoPedido.ACEPTADO, EstadoPedido.RECHAZADO, EstadoPedido.PREPARANDO, EstadoPedido.LISTO};
        String[] textos = {"✅ Aceptar pedido", "❌ Rechazar pedido", "👨‍🍳 Empezar a preparar", "📦 Marcar como listo"};
        List<String> op = new ArrayList<>();
        List<EstadoPedido> objetivo = new ArrayList<>();
        for (int i = 0; i < destinos.length; i++)
            if (p.getEstado().puedePasarA(destinos[i])) { op.add(textos[i]); objetivo.add(destinos[i]); }
        op.add("📍 Ver ubicación en Google Maps");
        new AlertDialog.Builder(this).setTitle("Pedido #" + p.getId())
            .setItems(op.toArray(new String[0]), (d, i) -> {
                if (i < objetivo.size()) cambiar(p, objetivo.get(i));
                else Ui.verEnGoogleMaps(this, p.getLatitud(), p.getLongitud(), "Entrega pedido #" + p.getId());
            }).show();
    }

    private void cambiar(Pedido p, EstadoPedido nuevo) {
        Repo.get().cambiarEstado(p.getId(), nuevo, new Callback<Pedido>() {
            @Override public void onOk(Pedido r) { cargar(); }
            @Override public void onError(String m) { Toast.makeText(PedidosComercioActivity.this, m, Toast.LENGTH_LONG).show(); }
        });
    }
}
