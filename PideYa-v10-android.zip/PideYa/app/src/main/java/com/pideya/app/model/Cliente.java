package com.pideya.app.model;

import com.pideya.app.ui.RestaurantesActivity;

public class Cliente extends Usuario {
    public Cliente(int id, String nombre, String email) { super(id, nombre, email, "cliente"); }
    @Override public Class<?> pantallaInicial() { return RestaurantesActivity.class; }
}
