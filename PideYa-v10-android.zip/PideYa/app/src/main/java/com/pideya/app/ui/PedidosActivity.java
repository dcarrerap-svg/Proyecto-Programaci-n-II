package com.pideya.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.pideya.app.R;
import com.pideya.app.data.Callback;
import com.pideya.app.data.Repo;
import com.pideya.app.model.EstadoPedido;
import com.pideya.app.model.Pedido;
import com.pideya.app.util.Sesion;
import com.pideya.app.util.Ui;
import java.util.ArrayList;
import java.util.List;

public class PedidosActivity extends AppCompatActivity {
    private final List<Pedido> datos = new ArrayList<>();
    private ListaAdapter<Pedido> ad;
    private RecyclerView rv;
    private TextView vacio;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_lista);
        Ui.insets(this, findViewById(R.id.header), findViewById(R.id.barra));
        ((TextView) findViewById(R.id.titulo)).setText("Mis pedidos");
        ((TextView) findViewById(R.id.subtitulo)).setText("Sigue el estado de tus pedidos");
        TextView resumen = findViewById(R.id.resumen);
        resumen.setText("🔄 Toca para actualizar");
        resumen.setOnClickListener(v -> cargar());
        Button btn = findViewById(R.id.boton);
        btn.setText("Ver restaurantes");
        btn.setOnClickListener(v -> {
            startActivity(new Intent(this, RestaurantesActivity.class));
            finish();
        });
        vacio = findViewById(R.id.vacio);
        rv = findViewById(R.id.lista);
        rv.setLayoutManager(new LinearLayoutManager(this));
        ad = new ListaAdapter<>(datos, R.layout.item_pedido, (v, p) -> {
            ((TextView) v.findViewById(R.id.numero)).setText("Pedido #" + p.getId());
            ((TextView) v.findViewById(R.id.restaurante)).setText(p.getRestaurante());
            ((TextView) v.findViewById(R.id.total)).setText(Ui.q(p.getTotal()));
            TextView chip = v.findViewById(R.id.estado);
            chip.setText(p.getEstado().etiqueta());
            chip.getBackground().mutate().setTint(p.getEstado().color());
            TextView pago = v.findViewById(R.id.pago);
            pago.setVisibility(View.VISIBLE);
            pago.setText(Ui.pago(p.getMetodoPago(), p.getCostoEnvio()));
            TextView cod = v.findViewById(R.id.codigo);
            boolean enCamino = p.getEstado() == EstadoPedido.EN_CAMINO;
            cod.setVisibility(enCamino ? View.VISIBLE : View.GONE);
            cod.setText("🔐 Toca para ver tu código de entrega");
            TextView cal = v.findViewById(R.id.calificar);
            int dadas = Math.max(p.getCalificacionEstrellas(), Sesion.calificaciones.getOrDefault(p.getId(), 0));
            if (p.getEstado() != EstadoPedido.ENTREGADO) {
                cal.setVisibility(View.GONE);
            } else if (dadas > 0) {
                cal.setVisibility(View.VISIBLE);
                cal.setText("Tu calificación: " + Ui.estrellas(dadas));
                cal.setClickable(false);
            } else {
                cal.setVisibility(View.VISIBLE);
                cal.setText("⭐ Calificar pedido");
                cal.setOnClickListener(x -> calificar(p));
            }
            v.setOnClickListener(x -> { if (enCamino) mostrarCodigo(p); });
        });
        rv.setAdapter(ad);
    }

    @Override protected void onResume() { super.onResume(); cargar(); }

    private void cargar() {
        Repo.get().getPedidos(Sesion.usuario.getId(), new Callback<List<Pedido>>() {
            @Override public void onOk(List<Pedido> l) {
                datos.clear(); datos.addAll(l);
                ad.notifyDataSetChanged(); rv.scheduleLayoutAnimation();
                vacio.setVisibility(datos.isEmpty() ? View.VISIBLE : View.GONE);
            }
            @Override public void onError(String m) { Toast.makeText(PedidosActivity.this, m, Toast.LENGTH_SHORT).show(); }
        });
    }

    private void mostrarCodigo(Pedido p) {
        Repo.get().getCodigo(p.getId(), new Callback<String>() {
            @Override public void onOk(String codigo) {
                new AlertDialog.Builder(PedidosActivity.this).setTitle("Código de entrega")
                    .setMessage(codigo == null || codigo.isEmpty() ? "Este pedido no tiene código." : "Dáselo al repartidor al recibir tu pedido:\n\n" + codigo)
                    .setPositiveButton("Entendido", null).show();
            }
            @Override public void onError(String m) { Toast.makeText(PedidosActivity.this, m, Toast.LENGTH_SHORT).show(); }
        });
    }

    private void calificar(Pedido p) {
        View vista = getLayoutInflater().inflate(R.layout.dialog_calificar, null);
        RatingBar barra = vista.findViewById(R.id.estrellas);
        EditText comentario = vista.findViewById(R.id.comentario);
        new AlertDialog.Builder(this).setTitle("Califica tu pedido #" + p.getId()).setView(vista)
            .setPositiveButton("Enviar", (d, w) -> {
                int estrellas = Math.max(1, Math.round(barra.getRating()));
                Repo.get().calificar(p.getId(), estrellas, comentario.getText().toString().trim(), new Callback<Boolean>() {
                    @Override public void onOk(Boolean ok) {
                        Sesion.calificaciones.put(p.getId(), estrellas);
                        p.setCalificacionEstrellas(estrellas);
                        ad.notifyDataSetChanged();
                        Toast.makeText(PedidosActivity.this, "¡Gracias por tu calificación!", Toast.LENGTH_SHORT).show();
                    }
                    @Override public void onError(String m) { Toast.makeText(PedidosActivity.this, m, Toast.LENGTH_LONG).show(); }
                });
            }).setNegativeButton("Cancelar", null).show();
    }
}
