package com.pideya.app.model;

import com.pideya.app.ui.EntregasActivity;

public class Repartidor extends Usuario {
    public Repartidor(int id, String nombre, String email) { super(id, nombre, email, "repartidor"); }
    @Override public Class<?> pantallaInicial() { return EntregasActivity.class; }
}
