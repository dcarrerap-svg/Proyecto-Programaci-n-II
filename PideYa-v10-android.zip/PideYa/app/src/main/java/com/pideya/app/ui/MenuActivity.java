package com.pideya.app.ui;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.pideya.app.R;
import com.pideya.app.data.Callback;
import com.pideya.app.data.Repo;
import com.pideya.app.model.*;
import com.pideya.app.util.Sesion;
import com.pideya.app.util.Ubicacion;
import com.pideya.app.util.Ui;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MenuActivity extends AppCompatActivity {
    private Restaurante rest;
    private final ActivityResultLauncher<String[]> permiso =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), r -> mostrarResumen());

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_lista);
        Ui.insets(this, findViewById(R.id.header), findViewById(R.id.barra));
        rest = Sesion.restaurante;
        ((TextView) findViewById(R.id.titulo)).setText(rest.getEmoji() + " " + rest.getNombre());
        ((TextView) findViewById(R.id.subtitulo)).setText(rest.getCategoria() + " · " + rest.getMeta());
        TextView resumen = findViewById(R.id.resumen);
        resumen.setText("Carrito vacío");
        Button btn = findViewById(R.id.boton);
        btn.setText("Pedir ahora");

        RecyclerView rv = findViewById(R.id.lista);
        rv.setLayoutManager(new LinearLayoutManager(this));
        List<Producto> menu = new ArrayList<>();
        ListaAdapter<Producto> ad = new ListaAdapter<>(menu, R.layout.item_producto, (v, p) -> {
            ((TextView) v.findViewById(R.id.emoji)).setText(p.getEmoji());
            ((TextView) v.findViewById(R.id.nombre)).setText(p.getNombre());
            ((TextView) v.findViewById(R.id.descripcion)).setText(p.getDescripcion());
            ((TextView) v.findViewById(R.id.precio)).setText(Ui.q(p.getPrecio()));
            v.findViewById(R.id.agregar).setOnClickListener(x -> {
                Sesion.carrito.add(p);
                double total = 0;
                for (Producto q : Sesion.carrito) total += q.getPrecio();
                resumen.setText(Sesion.carrito.size() + " productos · " + Ui.q(total));
                Ui.pulso(x); Ui.pulso(resumen);
            });
        });
        rv.setAdapter(ad);
        Repo.get().getMenu(rest.getId(), new Callback<List<Producto>>() {
            @Override public void onOk(List<Producto> l) { menu.addAll(l); ad.notifyDataSetChanged(); rv.scheduleLayoutAnimation(); }
            @Override public void onError(String m) { Toast.makeText(MenuActivity.this, m, Toast.LENGTH_SHORT).show(); }
        });
        btn.setOnClickListener(v -> iniciarPedido());
    }

    private void iniciarPedido() {
        if (Sesion.carrito.isEmpty()) { Toast.makeText(this, "Agrega al menos un producto.", Toast.LENGTH_SHORT).show(); return; }
        if (Ubicacion.tienePermiso(this)) mostrarResumen();
        else permiso.launch(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION});
    }

    private void mostrarResumen() {
        double[] u = Ubicacion.actual(this);
        double subtotal = 0;
        for (Producto p : Sesion.carrito) subtotal += p.getPrecio();
        double envio = Ui.costoEnvio(rest, u[0], u[1]);
        View vista = getLayoutInflater().inflate(R.layout.dialog_pago, null);
        ((TextView) vista.findViewById(R.id.detalle)).setText(
            (u[2] == 1 ? "📍 Entrega en tu ubicación actual" : "📍 Entrega en Ciudad de Guatemala (ubicación aproximada)")
            + "\n\nSubtotal: " + Ui.q(subtotal) + "\nEnvío estimado: " + Ui.q(envio) + "\nTotal: " + Ui.q(subtotal + envio));
        RadioGroup pagos = vista.findViewById(R.id.pagos);
        new AlertDialog.Builder(this).setTitle("Confirmar pedido").setView(vista)
            .setPositiveButton("Pedir", (d, w) -> {
                boolean tarjeta = pagos.getCheckedRadioButtonId() == R.id.pagoTarjeta;
                String codigo = String.format(Locale.US, "%04d", new SecureRandom().nextInt(10000));
                Entrega e = new Entrega(u[0], u[1], tarjeta ? "TARJETA" : "EFECTIVO", envio, codigo);
                Repo.get().crearPedido(Sesion.usuario, rest, Sesion.carrito, e, new Callback<Pedido>() {
                    @Override public void onOk(Pedido p) {
                        Sesion.pagos.put(p.getId(), (tarjeta ? "💳 Tarjeta" : "💵 Efectivo") + " · + envío " + Ui.q(envio));
                        Sesion.codigos.put(p.getId(), codigo);
                        Sesion.carrito.clear();
                        startActivity(new Intent(MenuActivity.this, PedidosActivity.class));
                        finish();
                    }
                    @Override public void onError(String m) { Toast.makeText(MenuActivity.this, m, Toast.LENGTH_LONG).show(); }
                });
            }).setNegativeButton("Cancelar", null).show();
    }
}
