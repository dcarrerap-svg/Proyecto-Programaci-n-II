package com.pideya.app.util;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.content.res.Configuration;
import android.view.View;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import java.util.Locale;

public class Ui {
    public static String q(double v) { return String.format(Locale.US, "Q%.2f", v); }

    /** Evita que la barra de estado, la de navegación y el teclado tapen el contenido. */
    public static void insets(Activity a, View top, View bottom) {
        int t0 = top.getPaddingTop(), b0 = bottom.getPaddingBottom();
        ViewCompat.setOnApplyWindowInsetsListener(a.findViewById(android.R.id.content), (v, w) -> {
            Insets s = w.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.ime());
            top.setPadding(top.getPaddingLeft(), t0 + s.top, top.getPaddingRight(), top.getPaddingBottom());
            bottom.setPadding(bottom.getPaddingLeft(), bottom.getPaddingTop(), bottom.getPaddingRight(), b0 + s.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
    }

    /** Efecto "rebote" al tocar. */
    public static void pulso(View v) {
        v.animate().scaleX(1.2f).scaleY(1.2f).setDuration(90)
            .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(120)).start();
    }

    /** Aparece deslizando desde abajo. */
    public static void entrada(View v) {
        v.setAlpha(0f); v.setTranslationY(80f);
        v.animate().alpha(1f).translationY(0f).setDuration(450).start();
    }

    public static void alternarTema(Activity a) {
        boolean noche = (a.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        int modo = noche ? AppCompatDelegate.MODE_NIGHT_NO : AppCompatDelegate.MODE_NIGHT_YES;
        a.getSharedPreferences("pideya", Context.MODE_PRIVATE).edit().putInt("tema", modo).apply();
        AppCompatDelegate.setDefaultNightMode(modo);
    }

    public static void aplicarTemaGuardado(Context c) {
        AppCompatDelegate.setDefaultNightMode(c.getSharedPreferences("pideya", Context.MODE_PRIVATE)
                .getInt("tema", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM));
    }

    public static String estrellas(int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= 5; i++) sb.append(i <= n ? "★" : "☆");
        return sb.toString();
    }

    public static double km(double la1, double lo1, double la2, double lo2) {
        double dLa = Math.toRadians(la2 - la1), dLo = Math.toRadians(lo2 - lo1);
        double a = Math.sin(dLa / 2) * Math.sin(dLa / 2)
                + Math.cos(Math.toRadians(la1)) * Math.cos(Math.toRadians(la2)) * Math.sin(dLo / 2) * Math.sin(dLo / 2);
        return 2 * 6371 * Math.asin(Math.sqrt(a));
    }

    /** Q8 base + Q2.50 por km (máximo Q60). Sin coordenadas del restaurante: tarifa fija de Q15. */
    public static double costoEnvio(com.pideya.app.model.Restaurante r, double lat, double lng) {
        if (!r.tieneUbicacion()) return 15;
        double v = 8 + 2.5 * km(r.getLatitud(), r.getLongitud(), lat, lng);
        return Math.round(Math.min(60, v) * 100) / 100.0;
    }

    /** Abre la ubicación en la app de Google Maps (o en el navegador si no está instalada). */
    public static void verEnGoogleMaps(Context c, double lat, double lng, String etiqueta) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:" + lat + "," + lng + "?q=" + lat + "," + lng + "(" + Uri.encode(etiqueta) + ")"));
        i.setPackage("com.google.android.apps.maps");
        try { c.startActivity(i); }
        catch (ActivityNotFoundException e) {
            c.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=" + lat + "," + lng)));
        }
    }

    public static void confirmarSalida(Activity a) {
        new androidx.appcompat.app.AlertDialog.Builder(a).setTitle("Cerrar sesión").setMessage("¿Seguro que quieres salir?")
            .setPositiveButton("Salir", (d, w) -> {
                Sesion.cerrar();
                a.startActivity(new Intent(a, com.pideya.app.ui.LoginActivity.class)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
            }).setNegativeButton("Cancelar", null).show();
    }

    public static String pago(String metodo, double envio) {
        return ("TARJETA".equals(metodo) ? "💳 Tarjeta" : "💵 Efectivo") + " · + envío " + q(envio);
    }
}
