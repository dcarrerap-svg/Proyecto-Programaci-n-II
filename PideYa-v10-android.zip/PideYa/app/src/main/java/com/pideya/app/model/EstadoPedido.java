package com.pideya.app.model;

/** Ciclo del pedido. Las reglas son las mismas que valida el backend. */
public enum EstadoPedido {
    PENDIENTE("⏳ Pendiente", 0xFFFFC93C), ACEPTADO("✅ Aceptado", 0xFF8CD867), RECHAZADO("❌ Rechazado", 0xFFFF8A80),
    PREPARANDO("👨‍🍳 Preparando", 0xFFFFC93C), LISTO("📦 Listo para recoger", 0xFF7FD6C4),
    EN_CAMINO("🛵 En camino", 0xFFFF7A3D), ENTREGADO("🎉 Entregado", 0xFF8CD867), CANCELADO("🚫 Cancelado", 0xFFBDBDBD);

    private final String etiqueta;
    private final int color;
    EstadoPedido(String etiqueta, int color) { this.etiqueta = etiqueta; this.color = color; }
    public String etiqueta() { return etiqueta; }
    public int color() { return color; }

    public EstadoPedido siguiente() {
        switch (this) {
            case PENDIENTE: return ACEPTADO;
            case ACEPTADO: return PREPARANDO;
            case PREPARANDO: return LISTO;
            case LISTO: return EN_CAMINO;
            case EN_CAMINO: return ENTREGADO;
            default: throw new IllegalStateException("El pedido ya no puede avanzar.");
        }
    }

    public boolean puedePasarA(EstadoPedido n) {
        switch (this) {
            case PENDIENTE: return n == ACEPTADO || n == RECHAZADO || n == CANCELADO;
            case ACEPTADO: return n == PREPARANDO || n == CANCELADO;
            case PREPARANDO: return n == LISTO;
            case LISTO: return n == EN_CAMINO;
            case EN_CAMINO: return n == ENTREGADO;
            default: return false;
        }
    }
}
