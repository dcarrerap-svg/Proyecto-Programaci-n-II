package com.pideya.app.model;

/** Datos del pedido que el backend aún no guarda: ubicación de entrega, pago, envío y código. */
public class Entrega {
    private final double latitud, longitud, costoEnvio;
    private final String metodoPago, codigo;

    public Entrega(double latitud, double longitud, String metodoPago, double costoEnvio, String codigo) {
        this.latitud = latitud; this.longitud = longitud; this.metodoPago = metodoPago;
        this.costoEnvio = costoEnvio; this.codigo = codigo;
    }
    public double getLatitud() { return latitud; }
    public double getLongitud() { return longitud; }
    public String getMetodoPago() { return metodoPago; }
    public double getCostoEnvio() { return costoEnvio; }
    public String getCodigo() { return codigo; }
}
