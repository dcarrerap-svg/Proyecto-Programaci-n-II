package com.pideya.app.data;

import com.pideya.app.model.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

/** Datos de prueba en memoria. Se reemplaza por ApiRepository cuando el backend esté listo. */
public class MockRepository implements DeliveryRepository {
    private final List<Restaurante> restaurantes = new ArrayList<>();
    private final List<Producto> productos = new ArrayList<>();
    private final List<Pedido> pedidos = new ArrayList<>();
    private int siguienteId = 1, siguienteUsuario = 3;
    private final Map<String, Usuario> usuarios = new HashMap<>();
    private final Map<String, String> claves = new HashMap<>();
    {
        usuarios.put("cliente@test.com", Usuario.crear(1, "Cliente Demo", "cliente@test.com", "cliente"));
        claves.put("cliente@test.com", "12345");
        usuarios.put("repartidor@test.com", Usuario.crear(2, "Repartidor Demo", "repartidor@test.com", "repartidor"));
        claves.put("repartidor@test.com", "12345");
        usuarios.put("comercio@test.com", Usuario.crear(1, "Pizza Roma", "comercio@test.com", "restaurante"));
        claves.put("comercio@test.com", "12345");
    }

    public MockRepository() {
        restaurantes.add(new Restaurante(1, "Pizza Roma", "Zona 4", "🍕", "Pizzas y pastas", 4.8, 25, 14.6200, -90.5150));
        restaurantes.add(new Restaurante(2, "Pollos Don Chepe", "Zona 10", "🍗", "Pollo frito", 4.6, 30, 14.6050, -90.5100));
        restaurantes.add(new Restaurante(3, "Café Central", "Zona 1", "☕", "Café y postres", 4.9, 15, 14.6410, -90.5130));
        restaurantes.add(new Restaurante(4, "Sushi Kai", "Zona 15", "🍣", "Sushi y asiática", 4.7, 35, 14.6000, -90.4850));
        productos.add(new Producto(1, "Pizza pepperoni", "Mozzarella, pepperoni y salsa de la casa", 65, 1, "🍕"));
        productos.add(new Producto(2, "Pasta alfredo", "Fettuccine con crema y parmesano", 48, 1, "🍝"));
        productos.add(new Producto(3, "Pollo frito (6 pzas)", "Crujiente, con guarnición", 55, 2, "🍗"));
        productos.add(new Producto(4, "Combo familiar", "12 piezas, papas y bebidas", 120, 2, "🍟"));
        productos.add(new Producto(5, "Capuchino", "Espresso con leche espumada", 22, 3, "☕"));
        productos.add(new Producto(6, "Pastel de chocolate", "Porción con cobertura de cacao", 30, 3, "🍰"));
        productos.add(new Producto(7, "Rollo California", "8 piezas con aguacate y cangrejo", 58, 4, "🍣"));
        productos.add(new Producto(8, "Ramen de cerdo", "Caldo miso, huevo y cebollín", 62, 4, "🍜"));
    }

    @Override public void login(String email, String password, Callback<Usuario> cb) {
        String k = email.toLowerCase();
        if (usuarios.containsKey(k) && claves.get(k).equals(password)) cb.onOk(usuarios.get(k));
        else cb.onError("Correo o contraseña incorrectos.");
    }

    @Override public void registrar(String nombre, String email, String password, String direccion, Callback<Usuario> cb) {
        String k = email.toLowerCase();
        if (usuarios.containsKey(k)) { cb.onError("Ese correo ya está registrado."); return; } // igual que el backend
        Usuario u = Usuario.crear(siguienteUsuario++, nombre, email, "cliente");
        usuarios.put(k, u);
        claves.put(k, password);
        cb.onOk(u);
    }

    @Override public void getRestaurantes(Callback<List<Restaurante>> cb) { cb.onOk(restaurantes); }

    @Override public void getMenu(int restauranteId, Callback<List<Producto>> cb) {
        List<Producto> menu = new ArrayList<>();
        for (Producto p : productos) if (p.getRestauranteId() == restauranteId) menu.add(p);
        cb.onOk(menu);
    }

    @Override public void crearPedido(Usuario u, Restaurante r, List<Producto> items, Entrega entrega, Callback<Pedido> cb) {
        if (items.isEmpty()) { cb.onError("El carrito está vacío."); return; }
        double total = 0;
        for (Producto p : items) total += p.getPrecio(); // el total se calcula aquí, como en el backend
        Pedido pedido = new Pedido(siguienteId++, u.getId(), r.getNombre(), total);
        pedido.setEntrega(entrega.getLatitud(), entrega.getLongitud(), u.getNombre());
        pedido.setPago(entrega.getMetodoPago(), entrega.getCostoEnvio());
        pedido.setRestauranteId(r.getId());
        pedido.setDetalle(detalle(items));
        codigos.put(pedido.getId(), entrega.getCodigo());
        pedidos.add(0, pedido);
        cb.onOk(pedido);
    }

    @Override public void getPedidos(int clienteId, Callback<List<Pedido>> cb) {
        List<Pedido> propios = new ArrayList<>();
        for (Pedido p : pedidos) if (p.getClienteId() == clienteId) propios.add(p);
        cb.onOk(propios);
    }

    private final java.util.Set<Integer> calificados = new java.util.HashSet<>();

    @Override public void calificar(int pedidoId, int estrellas, String comentario, Callback<Boolean> cb) {
        for (Pedido p : pedidos) {
            if (p.getId() == pedidoId) {
                if (p.getEstado() != EstadoPedido.ENTREGADO) { cb.onError("Solo se pueden calificar pedidos entregados."); return; }
                if (!calificados.add(pedidoId)) { cb.onError("Este pedido ya fue calificado."); return; }
                p.setCalificacionEstrellas(estrellas);
                cb.onOk(true);
                return;
            }
        }
        cb.onError("Pedido no encontrado.");
    }

    @Override public void getMisEntregas(int repartidorId, Callback<List<Pedido>> cb) {
        List<Pedido> l = new ArrayList<>();
        for (Pedido p : pedidos) if (p.getRepartidorId() == repartidorId) l.add(p);
        cb.onOk(l);
    }

    private final Map<Integer, String> codigos = new HashMap<>();

    private static String detalle(List<Producto> items) {
        Map<String, Integer> cant = new java.util.LinkedHashMap<>();
        for (Producto p : items) cant.merge(p.getNombre(), 1, Integer::sum);
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Integer> e : cant.entrySet()) {
            if (sb.length() > 0) sb.append("\n");
            sb.append(e.getValue()).append(" × ").append(e.getKey());
        }
        return sb.toString();
    }

    @Override public void getPedidosDisponibles(Callback<List<Pedido>> cb) {
        List<Pedido> l = new ArrayList<>();
        for (Pedido p : pedidos) if (p.getEstado() == EstadoPedido.LISTO) l.add(p);
        cb.onOk(l);
    }

    @Override public void tomarPedido(int pedidoId, int repartidorId, Callback<Pedido> cb) {
        for (Pedido p : pedidos) {
            if (p.getId() == pedidoId) {
                if (p.getEstado() != EstadoPedido.LISTO) { cb.onError("El pedido aún no está listo para recoger."); return; }
                p.setRepartidorId(repartidorId);
                p.avanzar();
                cb.onOk(p);
                return;
            }
        }
        cb.onError("Pedido no encontrado.");
    }

    @Override public void cambiarEstado(int pedidoId, EstadoPedido nuevo, Callback<Pedido> cb) {
        for (Pedido p : pedidos) {
            if (p.getId() == pedidoId) {
                if (nuevo == EstadoPedido.EN_CAMINO || nuevo == EstadoPedido.ENTREGADO || !p.getEstado().puedePasarA(nuevo)) {
                    cb.onError("Transición no permitida: " + p.getEstado() + " → " + nuevo);
                    return;
                }
                p.setEstado(nuevo);
                cb.onOk(p);
                return;
            }
        }
        cb.onError("Pedido no encontrado.");
    }

    @Override public void entregar(int pedidoId, String codigo, Callback<Pedido> cb) {
        for (Pedido p : pedidos) {
            if (p.getId() == pedidoId) {
                if (p.getEstado() != EstadoPedido.EN_CAMINO) { cb.onError("El pedido no está en camino."); return; }
                if (!codigo.equals(codigos.get(pedidoId))) { cb.onError("Código de entrega incorrecto."); return; }
                p.setEstado(EstadoPedido.ENTREGADO);
                cb.onOk(p);
                return;
            }
        }
        cb.onError("Pedido no encontrado.");
    }

    @Override public void getCodigo(int pedidoId, Callback<String> cb) { cb.onOk(codigos.get(pedidoId)); }

    @Override public void getPedidosComercio(int restauranteId, Callback<List<Pedido>> cb) {
        List<Pedido> l = new ArrayList<>();
        for (Pedido p : pedidos) if (p.getRestauranteId() == restauranteId) l.add(p);
        cb.onOk(l);
    }
}
