package com.pideya.app.data;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.pideya.app.model.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

/** Conexión real al backend Spring Boot (delivery-backend). */
public class ApiRepository implements DeliveryRepository {
    /** Emulador: 10.0.2.2 es tu PC. Celular real: la IP de tu PC en el WiFi, p. ej. http://192.168.1.10:8080/api/ */
    private static final String BASE_URL = "http://10.0.2.2:8080/api/";
    /** Provisional (Ciudad de Guatemala) hasta que la app use el GPS. */
    private static final double LAT_ENTREGA = 14.6349, LNG_ENTREGA = -90.5069;

    interface Api {
        @POST("clientes/login") Call<JsonObject> login(@Body JsonObject b);
        @POST("clientes/registro") Call<JsonObject> registro(@Body JsonObject b);
        @GET("restaurantes") Call<JsonArray> restaurantes();
        @GET("productos/restaurante/{id}") Call<JsonArray> menu(@Path("id") int id);
        @POST("pedidos") Call<JsonObject> crearPedido(@Body JsonObject b);
        @GET("pedidos/cliente/{id}") Call<JsonArray> pedidos(@Path("id") int id);
        @PUT("pedidos/{id}/estado") Call<JsonObject> estado(@Path("id") int id, @Body RequestBody estado);
        @GET("pedidos/estado/{estado}") Call<JsonArray> porEstado(@Path("estado") String estado);
        @GET("pedidos/repartidor/{id}") Call<JsonArray> deRepartidor(@Path("id") int id);
        @GET("pedidos/restaurante/{id}") Call<JsonArray> deRestaurante(@Path("id") int id);
        @GET("pedidos/{id}/codigo") Call<ResponseBody> codigo(@Path("id") int id);
        @PUT("pedidos/{id}/aceptar") Call<JsonObject> aceptar(@Path("id") int id);
        @PUT("pedidos/{id}/rechazar") Call<JsonObject> rechazar(@Path("id") int id);
        @PUT("pedidos/{id}/entregar") Call<JsonObject> entregar(@Path("id") int id, @Body RequestBody codigo);
        @PUT("pedidos/{id}/repartidor/{rep}") Call<JsonObject> asignar(@Path("id") int id, @Path("rep") int rep);
        @POST("calificaciones/pedido/{id}") Call<JsonObject> calificar(@Path("id") int id, @Body JsonObject b);
    }

    private interface Mapper<T, R> { R map(T t) throws Exception; }

    private final Api api = new Retrofit.Builder().baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create()).build().create(Api.class);
    private final Map<Integer, Pedido> cache = new HashMap<>();

    private <T, R> void llamar(Call<T> call, String errorHttp, Mapper<T, R> mapa, Callback<R> cb) {
        call.enqueue(new retrofit2.Callback<T>() {
            @Override public void onResponse(Call<T> c, Response<T> r) {
                if (!r.isSuccessful() || r.body() == null) {
                    cb.onError(errorHttp != null ? errorHttp : "Error del servidor (" + r.code() + ").");
                    return;
                }
                R res;
                try { res = mapa.map(r.body()); }
                catch (Exception e) { cb.onError(e.getMessage() != null ? e.getMessage() : "Respuesta inesperada del servidor."); return; }
                cb.onOk(res);
            }
            @Override public void onFailure(Call<T> c, Throwable t) {
                cb.onError("No se pudo conectar con el servidor. ¿Está encendido el backend?");
            }
        });
    }

    // ---------- conversión JSON -> modelos de la app ----------
    private static String s(JsonObject o, String k, String def) {
        return o != null && o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : def;
    }
    private static double d(JsonObject o, String k) {
        return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsDouble() : 0;
    }
    private static Usuario usuario(JsonObject o) {
        // el backend no envía el tipo: se deduce por los campos propios de cada rol
        String tipo = o.has("nombreComercial") ? "restaurante" : o.has("vehiculo") ? "repartidor"
                : o.has("direccionFavorita") ? "cliente" : "admin";
        if (!tipo.equals("cliente") && !tipo.equals("repartidor") && !tipo.equals("restaurante"))
            throw new IllegalStateException("Esta app es para clientes, repartidores y comercios.");
        return Usuario.crear(o.get("id").getAsInt(), s(o, "nombre", ""), s(o, "email", ""), tipo);
    }
    private static Restaurante restaurante(JsonObject o) {
        // emoji, categoría, calificación y minutos aún no existen en el backend
        return new Restaurante(o.get("id").getAsInt(), s(o, "nombreComercial", s(o, "nombre", "Restaurante")),
                s(o, "direccion", ""), "🍽️", "Restaurante", 0, 0, d(o, "latitud"), d(o, "longitud"));
    }
    private static Pedido pedido(JsonObject o) {
        JsonObject r = o.getAsJsonObject("restaurante");
        EstadoPedido estado;
        try { estado = EstadoPedido.valueOf(s(o, "estado", "PENDIENTE")); }
        catch (IllegalArgumentException e) { estado = EstadoPedido.PENDIENTE; }
        Pedido p = new Pedido(o.get("id").getAsInt(), o.getAsJsonObject("cliente").get("id").getAsInt(),
                s(r, "nombreComercial", s(r, "nombre", "Restaurante")), d(o, "total"), estado);
        p.setEntrega(d(o, "latitudEntrega"), d(o, "longitudEntrega"), s(o.getAsJsonObject("cliente"), "nombre", ""));
        p.setPago(s(o, "metodoPago", "EFECTIVO"), d(o, "costoEnvio"));
        if (o.has("calificacionEstrellas") && !o.get("calificacionEstrellas").isJsonNull())
            p.setCalificacionEstrellas(o.get("calificacionEstrellas").getAsInt());
        StringBuilder sb = new StringBuilder();
        if (o.has("detalles") && o.get("detalles").isJsonArray()) {
            for (JsonElement el : o.getAsJsonArray("detalles")) {
                JsonObject it = el.getAsJsonObject();
                if (sb.length() > 0) sb.append("\n");
                sb.append(it.get("cantidad").getAsInt()).append(" × ").append(s(it.getAsJsonObject("producto"), "nombre", "Producto"));
            }
        }
        p.setDetalle(sb.toString());
        return p;
    }
    private Pedido guardar(Pedido p) { cache.put(p.getId(), p); return p; }

    // ---------- operaciones ----------
    @Override public void login(String email, String password, Callback<Usuario> cb) {
        JsonObject b = new JsonObject();
        b.addProperty("email", email);
        b.addProperty("password", password);
        llamar(api.login(b), "Correo o contraseña incorrectos.", ApiRepository::usuario, cb);
    }

    @Override public void registrar(String nombre, String email, String password, String direccion, Callback<Usuario> cb) {
        JsonObject b = new JsonObject();
        b.addProperty("nombre", nombre);
        b.addProperty("email", email);
        b.addProperty("password", password);
        b.addProperty("direccionFavorita", direccion);
        llamar(api.registro(b), "No se pudo crear la cuenta. ¿Ese correo ya está registrado?", ApiRepository::usuario, cb);
    }

    @Override public void getRestaurantes(Callback<List<Restaurante>> cb) {
        llamar(api.restaurantes(), null, a -> {
            List<Restaurante> l = new ArrayList<>();
            for (JsonElement e : a) l.add(restaurante(e.getAsJsonObject()));
            return l;
        }, cb);
    }

    @Override public void getMenu(int restauranteId, Callback<List<Producto>> cb) {
        llamar(api.menu(restauranteId), null, a -> {
            List<Producto> l = new ArrayList<>();
            for (JsonElement e : a) {
                JsonObject o = e.getAsJsonObject();
                if (o.has("disponible") && !o.get("disponible").getAsBoolean()) continue;
                l.add(new Producto(o.get("id").getAsInt(), s(o, "nombre", ""), s(o, "descripcion", ""),
                        d(o, "precio"), restauranteId, "🍴"));
            }
            return l;
        }, cb);
    }

    @Override public void crearPedido(Usuario u, Restaurante r, List<Producto> items, Entrega entrega, Callback<Pedido> cb) {
        if (items.isEmpty()) { cb.onError("El carrito está vacío."); return; }
        Map<Integer, Integer> cantidades = new LinkedHashMap<>();
        for (Producto p : items) cantidades.merge(p.getId(), 1, Integer::sum);
        JsonArray arr = new JsonArray();
        for (Map.Entry<Integer, Integer> e : cantidades.entrySet()) {
            JsonObject it = new JsonObject();
            it.addProperty("productoId", e.getKey());
            it.addProperty("cantidad", e.getValue());
            arr.add(it);
        }
        JsonObject b = new JsonObject();
        b.addProperty("clienteId", u.getId());
        b.addProperty("restauranteId", r.getId());
        b.addProperty("latitudEntrega", entrega.getLatitud());
        b.addProperty("longitudEntrega", entrega.getLongitud());
        b.addProperty("metodoPago", entrega.getMetodoPago());
        b.addProperty("costoEnvio", entrega.getCostoEnvio());
        b.add("items", arr);
        llamar(api.crearPedido(b), "No se pudo crear el pedido. Revisa que el cliente y el restaurante existan.",
                o -> guardar(pedido(o)), cb);
    }

    @Override public void getPedidos(int clienteId, Callback<List<Pedido>> cb) {
        llamar(api.pedidos(clienteId), null, a -> {
            List<Pedido> l = new ArrayList<>();
            for (JsonElement e : a) l.add(guardar(pedido(e.getAsJsonObject())));
            Collections.sort(l, (x, y) -> y.getId() - x.getId()); // más recientes primero
            return l;
        }, cb);
    }

    @Override public void calificar(int pedidoId, int estrellas, String comentario, Callback<Boolean> cb) {
        JsonObject b = new JsonObject();
        b.addProperty("estrellas", estrellas);
        b.addProperty("comentario", comentario);
        llamar(api.calificar(pedidoId, b), "No se pudo calificar. Solo se califican pedidos entregados y una sola vez.", o -> true, cb);
    }

    private static final String ERR_ESTADO = "No se pudo cambiar el estado. Puede que esa transición no esté permitida.";

    @Override public void getPedidosDisponibles(Callback<List<Pedido>> cb) { lista(api.porEstado("LISTO"), cb); }

    @Override public void getMisEntregas(int repartidorId, Callback<List<Pedido>> cb) { lista(api.deRepartidor(repartidorId), cb); }

    @Override public void getPedidosComercio(int restauranteId, Callback<List<Pedido>> cb) { lista(api.deRestaurante(restauranteId), cb); }

    private void lista(Call<JsonArray> call, Callback<List<Pedido>> cb) {
        llamar(call, null, a -> {
            List<Pedido> l = new ArrayList<>();
            for (JsonElement e : a) l.add(guardar(pedido(e.getAsJsonObject())));
            Collections.sort(l, (x, y) -> y.getId() - x.getId());
            return l;
        }, cb);
    }

    @Override public void tomarPedido(int pedidoId, int repartidorId, Callback<Pedido> cb) {
        llamar(api.asignar(pedidoId, repartidorId), "No se pudo tomar el pedido. Debe estar LISTO.", o -> guardar(pedido(o)), cb);
    }

    @Override public void cambiarEstado(int pedidoId, EstadoPedido nuevo, Callback<Pedido> cb) {
        Call<JsonObject> call = nuevo == EstadoPedido.ACEPTADO ? api.aceptar(pedidoId)
                : nuevo == EstadoPedido.RECHAZADO ? api.rechazar(pedidoId)
                : api.estado(pedidoId, RequestBody.create(MediaType.parse("text/plain"), nuevo.name()));
        llamar(call, ERR_ESTADO, o -> guardar(pedido(o)), cb);
    }

    @Override public void entregar(int pedidoId, String codigo, Callback<Pedido> cb) {
        RequestBody body = RequestBody.create(MediaType.parse("text/plain"), codigo);
        llamar(api.entregar(pedidoId, body), "Código incorrecto, o el pedido no está en camino.", o -> guardar(pedido(o)), cb);
    }

    @Override public void getCodigo(int pedidoId, Callback<String> cb) {
        llamar(api.codigo(pedidoId), null, r -> r.string().trim(), cb);
    }
}
