package com.pideya.app.ui;

import android.Manifest;
import android.content.Intent;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import com.pideya.app.util.Ubicacion;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.pideya.app.R;
import com.pideya.app.data.Callback;
import com.pideya.app.data.Repo;
import com.pideya.app.model.Restaurante;
import com.pideya.app.util.Sesion;
import com.pideya.app.util.Ui;
import java.util.ArrayList;
import java.util.List;

public class RestaurantesActivity extends AppCompatActivity {
    private final ActivityResultLauncher<String[]> permiso =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), r -> Ubicacion.actualizar(this));

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_lista);
        Ui.insets(this, findViewById(R.id.header), findViewById(R.id.barra));
        if (Ubicacion.tienePermiso(this)) Ubicacion.actualizar(this);
        else permiso.launch(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION});
        ((TextView) findViewById(R.id.titulo)).setText("Hola, " + Sesion.usuario.getNombre() + " 👋");
        ((TextView) findViewById(R.id.subtitulo)).setText("¿Qué se te antoja hoy?");
        ((TextView) findViewById(R.id.resumen)).setText("¿Ya pediste?");
        findViewById(R.id.tema).setVisibility(android.view.View.VISIBLE);
        findViewById(R.id.tema).setOnClickListener(v -> Ui.alternarTema(this));
        findViewById(R.id.salir).setVisibility(android.view.View.VISIBLE);
        findViewById(R.id.salir).setOnClickListener(v -> new androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Cerrar sesión").setMessage("¿Seguro que quieres salir?")
            .setPositiveButton("Salir", (d, w) -> {
                Sesion.cerrar();
                startActivity(new Intent(this, LoginActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
            })
            .setNegativeButton("Cancelar", null).show());
        Button btn = findViewById(R.id.boton);
        btn.setText("Mis pedidos");
        btn.setOnClickListener(v -> startActivity(new Intent(this, PedidosActivity.class)));

        RecyclerView rv = findViewById(R.id.lista);
        rv.setLayoutManager(new LinearLayoutManager(this));
        List<Restaurante> datos = new ArrayList<>();
        ListaAdapter<Restaurante> ad = new ListaAdapter<>(datos, R.layout.item_restaurante, (v, r) -> {
            ((TextView) v.findViewById(R.id.emoji)).setText(r.getEmoji());
            ((TextView) v.findViewById(R.id.nombre)).setText(r.getNombre());
            ((TextView) v.findViewById(R.id.detalle)).setText(r.getCategoria() + " · " + r.getDireccion());
            ((TextView) v.findViewById(R.id.meta)).setText(r.getMeta());
            v.setOnClickListener(x -> {
                Sesion.restaurante = r;
                Sesion.carrito.clear();
                startActivity(new Intent(this, MenuActivity.class));
            });
        });
        rv.setAdapter(ad);
        Repo.get().getRestaurantes(new Callback<List<Restaurante>>() {
            @Override public void onOk(List<Restaurante> l) { datos.addAll(l); ad.notifyDataSetChanged(); rv.scheduleLayoutAnimation(); }
            @Override public void onError(String m) { Toast.makeText(RestaurantesActivity.this, m, Toast.LENGTH_SHORT).show(); }
        });
    }
}
