package com.pideya.app.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.pideya.app.R;
import com.pideya.app.data.Callback;
import com.pideya.app.data.Repo;
import com.pideya.app.model.EstadoPedido;
import com.pideya.app.model.Pedido;
import com.pideya.app.util.Sesion;
import com.pideya.app.util.Ui;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Pantalla principal del repartidor: pedidos disponibles y sus entregas. */
public class EntregasActivity extends AppCompatActivity {
    private boolean verMias = false;
    private final List<Pedido> datos = new ArrayList<>();
    private ListaAdapter<Pedido> ad;
    private TextView titulo, resumen, vacio;
    private Button btn;
    private RecyclerView rv;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_lista);
        Ui.insets(this, findViewById(R.id.header), findViewById(R.id.barra));
        titulo = findViewById(R.id.titulo);
        resumen = findViewById(R.id.resumen);
        vacio = findViewById(R.id.vacio);
        btn = findViewById(R.id.boton);
        rv = findViewById(R.id.lista);
        ((TextView) findViewById(R.id.subtitulo)).setText("Hola, " + Sesion.usuario.getNombre() + " 🛵");
        findViewById(R.id.tema).setVisibility(View.VISIBLE);
        findViewById(R.id.tema).setOnClickListener(v -> Ui.alternarTema(this));
        findViewById(R.id.salir).setVisibility(View.VISIBLE);
        findViewById(R.id.salir).setOnClickListener(v -> Ui.confirmarSalida(this));

        rv.setLayoutManager(new LinearLayoutManager(this));
        ad = new ListaAdapter<>(datos, R.layout.item_pedido, (v, p) -> {
            EstadoPedido e = p.getEstado();
            ((TextView) v.findViewById(R.id.numero)).setText("Pedido #" + p.getId());
            ((TextView) v.findViewById(R.id.restaurante)).setText(p.getRestaurante() + "  →  " + p.getClienteNombre());
            ((TextView) v.findViewById(R.id.total)).setText(Ui.q(p.getTotal()));
            TextView chip = v.findViewById(R.id.estado);
            chip.setText(e.etiqueta());
            chip.getBackground().mutate().setTint(e.color());
            TextView ubic = v.findViewById(R.id.pago);
            ubic.setVisibility(View.VISIBLE);
            ubic.setText(String.format(Locale.US, "📍 Entrega en %.5f, %.5f", p.getLatitud(), p.getLongitud()));
            v.findViewById(R.id.codigo).setVisibility(View.GONE);
            v.findViewById(R.id.calificar).setVisibility(View.GONE);
            v.setOnClickListener(x -> opciones(p));
        });
        rv.setAdapter(ad);
        btn.setOnClickListener(v -> { verMias = !verMias; cargar(); });
        cargar();
    }

    private void cargar() {
        titulo.setText(verMias ? "Mis entregas" : "Pedidos disponibles");
        resumen.setText(verMias ? "Tus entregas" : "Pedidos listos para recoger");
        btn.setText(verMias ? "Ver disponibles" : "Mis entregas");
        vacio.setText(verMias ? "🛵\nAún no tienes entregas" : "😴\nNo hay pedidos disponibles");
        Callback<List<Pedido>> cb = new Callback<List<Pedido>>() {
            @Override public void onOk(List<Pedido> l) {
                datos.clear(); datos.addAll(l);
                ad.notifyDataSetChanged(); rv.scheduleLayoutAnimation();
                vacio.setVisibility(datos.isEmpty() ? View.VISIBLE : View.GONE);
            }
            @Override public void onError(String m) { Toast.makeText(EntregasActivity.this, m, Toast.LENGTH_SHORT).show(); }
        };
        if (verMias) Repo.get().getMisEntregas(Sesion.usuario.getId(), cb);
        else Repo.get().getPedidosDisponibles(cb);
    }

    private void opciones(Pedido p) {
        List<String> op = new ArrayList<>();
        op.add("📍 Ver ubicación en Google Maps");
        if (p.getEstado() == EstadoPedido.LISTO) op.add("🛵 Tomar pedido");
        if (p.getEstado() == EstadoPedido.EN_CAMINO) op.add("✅ Confirmar entrega con código");
        new AlertDialog.Builder(this).setTitle("Pedido #" + p.getId())
            .setItems(op.toArray(new String[0]), (d, i) -> {
                if (i == 0) Ui.verEnGoogleMaps(this, p.getLatitud(), p.getLongitud(), "Entrega pedido #" + p.getId());
                else if (op.get(i).startsWith("🛵")) tomar(p);
                else entregar(p);
            }).show();
    }

    private void tomar(Pedido p) {
        Repo.get().tomarPedido(p.getId(), Sesion.usuario.getId(), new Callback<Pedido>() {
            @Override public void onOk(Pedido r) { Toast.makeText(EntregasActivity.this, "Pedido asignado a ti", Toast.LENGTH_SHORT).show(); cargar(); }
            @Override public void onError(String m) { Toast.makeText(EntregasActivity.this, m, Toast.LENGTH_LONG).show(); }
        });
    }

    private void entregar(Pedido p) {
        EditText campo = new EditText(this);
        campo.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        campo.setHint("Código de 4 dígitos");
        FrameLayout caja = new FrameLayout(this);
        caja.setPadding(60, 20, 60, 0);
        caja.addView(campo);
        new AlertDialog.Builder(this).setTitle("Confirmar entrega").setMessage("Pide al cliente su código de entrega.").setView(caja)
            .setPositiveButton("Confirmar", (d, w) -> Repo.get().entregar(p.getId(), campo.getText().toString().trim(), new Callback<Pedido>() {
                @Override public void onOk(Pedido r) { Toast.makeText(EntregasActivity.this, "¡Entrega confirmada!", Toast.LENGTH_SHORT).show(); cargar(); }
                @Override public void onError(String m) { Toast.makeText(EntregasActivity.this, m, Toast.LENGTH_LONG).show(); }
            })).setNegativeButton("Cancelar", null).show();
    }
}
