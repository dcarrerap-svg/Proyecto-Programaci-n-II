package com.pideya.app.data;

import com.pideya.app.model.*;
import java.util.List;

public interface DeliveryRepository {
    void login(String email, String password, Callback<Usuario> cb);
    void registrar(String nombre, String email, String password, String direccion, Callback<Usuario> cb);
    void getRestaurantes(Callback<List<Restaurante>> cb);
    void getMenu(int restauranteId, Callback<List<Producto>> cb);
    void crearPedido(Usuario u, Restaurante r, List<Producto> items, Entrega entrega, Callback<Pedido> cb);
    void getPedidos(int clienteId, Callback<List<Pedido>> cb);
    void cambiarEstado(int pedidoId, EstadoPedido nuevo, Callback<Pedido> cb);
    void entregar(int pedidoId, String codigo, Callback<Pedido> cb);
    void getCodigo(int pedidoId, Callback<String> cb);
    void getPedidosComercio(int restauranteId, Callback<List<Pedido>> cb);
    void calificar(int pedidoId, int estrellas, String comentario, Callback<Boolean> cb);
    void getPedidosDisponibles(Callback<List<Pedido>> cb);
    void getMisEntregas(int repartidorId, Callback<List<Pedido>> cb);
    void tomarPedido(int pedidoId, int repartidorId, Callback<Pedido> cb);
}
