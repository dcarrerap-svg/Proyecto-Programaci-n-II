package com.pideya.app.model;

/** Clase base. Igual que en el backend, cada rol hereda y define su pantalla inicial (polimorfismo). */
public abstract class Usuario {
    private final int id;
    private final String nombre, email, tipoUsuario;

    protected Usuario(int id, String nombre, String email, String tipoUsuario) {
        this.id = id; this.nombre = nombre; this.email = email; this.tipoUsuario = tipoUsuario;
    }
    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getEmail() { return email; }
    public String getTipoUsuario() { return tipoUsuario; }

    /** Pantalla a la que entra este rol después del login (equivale a obtenerPanel() del backend). */
    public abstract Class<?> pantallaInicial();

    public static Usuario crear(int id, String nombre, String email, String tipo) {
        if ("repartidor".equals(tipo)) return new Repartidor(id, nombre, email);
        if ("restaurante".equals(tipo)) return new Comercio(id, nombre, email);
        return new Cliente(id, nombre, email);
    }
}
