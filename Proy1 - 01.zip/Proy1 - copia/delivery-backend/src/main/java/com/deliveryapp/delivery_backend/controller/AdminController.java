package com.deliveryapp.delivery_backend.controller;

import com.deliveryapp.delivery_backend.model.Admin;
import com.deliveryapp.delivery_backend.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admins")
public class AdminController {

    @Autowired
    private UsuarioService usuarioService;

    @PostMapping("/registro")
    public Admin registrar(@RequestBody Admin admin) {
        return usuarioService.registrarAdmin(admin);
    }
}
