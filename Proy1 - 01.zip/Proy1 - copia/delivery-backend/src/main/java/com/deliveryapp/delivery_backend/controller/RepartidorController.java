package com.deliveryapp.delivery_backend.controller;

import com.deliveryapp.delivery_backend.model.Repartidor;
import com.deliveryapp.delivery_backend.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/repartidores")
public class RepartidorController {

    @Autowired
    private UsuarioService usuarioService;

    @PostMapping("/registro")
    public Repartidor registrar(@RequestBody Repartidor repartidor) {
        return usuarioService.registrarRepartidor(repartidor);
    }
}
