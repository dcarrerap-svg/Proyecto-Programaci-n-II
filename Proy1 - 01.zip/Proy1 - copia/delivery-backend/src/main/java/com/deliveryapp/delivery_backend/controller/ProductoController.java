package com.deliveryapp.delivery_backend.controller;

import com.deliveryapp.delivery_backend.model.Producto;
import com.deliveryapp.delivery_backend.service.ProductoService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/productos")
public class ProductoController {

    @Autowired
    private ProductoService productoService;

    @PostMapping
    public Producto crear(@RequestBody Producto producto) {
        return productoService.crear(producto);
    }

    @GetMapping("/restaurante/{restauranteId}")
    public List<Producto> listarPorRestaurante(@PathVariable Long restauranteId) {
        return productoService.listarPorRestaurante(restauranteId);
    }
        @PutMapping("/{id}")
    public Producto actualizar(@PathVariable Long id, @RequestBody Producto producto) {
        return productoService.actualizar(id, producto);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        productoService.eliminar(id);
    }
}