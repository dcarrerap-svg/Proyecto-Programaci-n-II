package com.deliveryapp.delivery_backend.service;

import com.deliveryapp.delivery_backend.model.Producto;
import com.deliveryapp.delivery_backend.repository.ProductoRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductoService {

    @Autowired
    private ProductoRepository productoRepository;

    public Producto crear(Producto producto) {
        return productoRepository.save(producto);
    }

    public List<Producto> listarPorRestaurante(Long restauranteId) {
        return productoRepository.findByRestauranteId(restauranteId);
    }
        public Producto actualizar(Long id, Producto datosNuevos) {
        Producto producto = productoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado"));
        producto.setNombre(datosNuevos.getNombre());
        producto.setDescripcion(datosNuevos.getDescripcion());
        producto.setPrecio(datosNuevos.getPrecio());
        producto.setDisponible(datosNuevos.isDisponible());
        return productoRepository.save(producto);
    }

    public void eliminar(Long id) {
        productoRepository.deleteById(id);
    }
}