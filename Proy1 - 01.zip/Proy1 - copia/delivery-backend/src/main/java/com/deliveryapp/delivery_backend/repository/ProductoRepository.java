package com.deliveryapp.delivery_backend.repository;

import com.deliveryapp.delivery_backend.model.Producto;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductoRepository extends JpaRepository<Producto, Long> {

    List<Producto> findByRestauranteId(Long restauranteId);
}