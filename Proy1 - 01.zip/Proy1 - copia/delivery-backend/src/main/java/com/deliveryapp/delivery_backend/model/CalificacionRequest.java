package com.deliveryapp.delivery_backend.model;

import lombok.Data;

@Data
public class CalificacionRequest {
    private Integer estrellas;
    private String comentario;
}