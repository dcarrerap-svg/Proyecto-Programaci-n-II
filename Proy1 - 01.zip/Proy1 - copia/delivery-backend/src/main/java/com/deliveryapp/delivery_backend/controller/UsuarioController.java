package com.deliveryapp.delivery_backend.controller;

import com.deliveryapp.delivery_backend.model.Cliente;
import com.deliveryapp.delivery_backend.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.deliveryapp.delivery_backend.model.LoginRequest;
import com.deliveryapp.delivery_backend.model.Usuario;

@RestController
@RequestMapping("/api/clientes")
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    @PostMapping("/registro")
    public Cliente registrar(@RequestBody Cliente cliente) {
        return usuarioService.registrarCliente(cliente);
    }
        @PostMapping("/login")
    public Usuario login(@RequestBody LoginRequest loginRequest) {
        return usuarioService.login(loginRequest.getEmail(), loginRequest.getPassword());
    }
}
