package com.deliveryapp.delivery_backend.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@DiscriminatorValue("ADMIN")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class Admin extends Usuario {

    @Override
    public String obtenerPanel() {
        return "Panel de Admin: gestionar restaurantes, ver estadísticas, resolver disputas";
    }
}