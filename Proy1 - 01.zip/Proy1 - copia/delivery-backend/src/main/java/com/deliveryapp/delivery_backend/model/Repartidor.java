package com.deliveryapp.delivery_backend.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@DiscriminatorValue("REPARTIDOR")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class Repartidor extends Usuario {

    private String vehiculo;
    private boolean disponible = true;

    @Override
    public String obtenerPanel() {
        return "Panel de Repartidor: ver pedidos disponibles, marcar entregas";
    }
}