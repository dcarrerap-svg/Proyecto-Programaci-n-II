package com.deliveryapp.delivery_backend.controller;

import com.deliveryapp.delivery_backend.model.Calificacion;
import com.deliveryapp.delivery_backend.model.CalificacionRequest;
import com.deliveryapp.delivery_backend.service.CalificacionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/calificaciones")
public class CalificacionController {

    @Autowired
    private CalificacionService calificacionService;

    @PostMapping("/pedido/{pedidoId}")
    public Calificacion calificar(@PathVariable Long pedidoId, @RequestBody CalificacionRequest request) {
        return calificacionService.calificar(pedidoId, request.getEstrellas(), request.getComentario());
    }
}