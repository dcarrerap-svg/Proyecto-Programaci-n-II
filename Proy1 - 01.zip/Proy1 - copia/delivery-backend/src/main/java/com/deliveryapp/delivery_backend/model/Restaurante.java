package com.deliveryapp.delivery_backend.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@DiscriminatorValue("RESTAURANTE")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class Restaurante extends Usuario {

    private String nombreComercial;
    private String direccion;
    private boolean activo = true;

    @Override
    public String obtenerPanel() {
        return "Panel de Restaurante: gestionar menú, ver pedidos entrantes";
    }
}