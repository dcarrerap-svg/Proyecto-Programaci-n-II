package com.deliveryapp.delivery_backend.repository;

import com.deliveryapp.delivery_backend.model.Calificacion;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CalificacionRepository extends JpaRepository<Calificacion, Long> {

    Optional<Calificacion> findByPedidoId(Long pedidoId);
}