package com.deliveryapp.delivery_backend.service;

import com.deliveryapp.delivery_backend.model.Cliente;
import com.deliveryapp.delivery_backend.model.Usuario;
import com.deliveryapp.delivery_backend.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.deliveryapp.delivery_backend.model.Restaurante;
import com.deliveryapp.delivery_backend.model.Repartidor;
import com.deliveryapp.delivery_backend.model.Admin;
import org.springframework.security.crypto.password.PasswordEncoder;
import java.util.List;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public Cliente registrarCliente(Cliente cliente) {
        if (usuarioRepository.findByEmail(cliente.getEmail()).isPresent()) {
            throw new RuntimeException("Ya existe un usuario con ese email");
        }
        cliente.setPassword(passwordEncoder.encode(cliente.getPassword()));
        return usuarioRepository.save(cliente);
    }

    public Usuario buscarPorEmail(String email) {
        return usuarioRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
    }

    public Usuario login(String email, String password) {
        Usuario usuario = buscarPorEmail(email);
        if (!passwordEncoder.matches(password, usuario.getPassword())) {
            throw new RuntimeException("Contraseña incorrecta");
        }
        return usuario;
    }

    public Restaurante registrarRestaurante(Restaurante restaurante) {
        if (usuarioRepository.findByEmail(restaurante.getEmail()).isPresent()) {
            throw new RuntimeException("Ya existe un usuario con ese email");
        }
        restaurante.setPassword(passwordEncoder.encode(restaurante.getPassword()));
        return usuarioRepository.save(restaurante);
    }

    public Repartidor registrarRepartidor(Repartidor repartidor) {
        if (usuarioRepository.findByEmail(repartidor.getEmail()).isPresent()) {
            throw new RuntimeException("Ya existe un usuario con ese email");
        }
        repartidor.setPassword(passwordEncoder.encode(repartidor.getPassword()));
        return usuarioRepository.save(repartidor);
    }

    public Admin registrarAdmin(Admin admin) {
        if (usuarioRepository.findByEmail(admin.getEmail()).isPresent()) {
            throw new RuntimeException("Ya existe un usuario con ese email");
        }
        admin.setPassword(passwordEncoder.encode(admin.getPassword()));
        return usuarioRepository.save(admin);
    }
    
    public List<Restaurante> listarRestaurantes() {
        return usuarioRepository.findAll().stream()
                .filter(u -> u instanceof Restaurante)
                .map(u -> (Restaurante) u)
                .filter(Restaurante::isActivo)
                .toList();
    }
}