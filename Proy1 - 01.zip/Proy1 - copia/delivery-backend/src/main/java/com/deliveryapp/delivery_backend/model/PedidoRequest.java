package com.deliveryapp.delivery_backend.model;

import lombok.Data;
import java.util.List;

@Data
public class PedidoRequest {
    private Long clienteId;
    private Long restauranteId;
    private List<ItemPedido> items;
    private Double latitudEntrega;
    private Double longitudEntrega;
    

    @Data
    public static class ItemPedido {
        private Long productoId;
        private Integer cantidad;
    }
}