package com.deliveryapp.delivery_backend.service;

import com.deliveryapp.delivery_backend.model.Calificacion;
import com.deliveryapp.delivery_backend.model.Pedido;
import com.deliveryapp.delivery_backend.repository.CalificacionRepository;
import com.deliveryapp.delivery_backend.repository.PedidoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CalificacionService {

    @Autowired
    private CalificacionRepository calificacionRepository;

    @Autowired
    private PedidoRepository pedidoRepository;

    public Calificacion calificar(Long pedidoId, Integer estrellas, String comentario) {
        Pedido pedido = pedidoRepository.findById(pedidoId)
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));

        if (!"ENTREGADO".equals(pedido.getEstado())) {
            throw new RuntimeException("Solo se pueden calificar pedidos entregados");
        }

        if (calificacionRepository.findByPedidoId(pedidoId).isPresent()) {
            throw new RuntimeException("Este pedido ya fue calificado");
        }

        Calificacion calificacion = new Calificacion();
        calificacion.setPedido(pedido);
        calificacion.setEstrellas(estrellas);
        calificacion.setComentario(comentario);
        return calificacionRepository.save(calificacion);
    }
}