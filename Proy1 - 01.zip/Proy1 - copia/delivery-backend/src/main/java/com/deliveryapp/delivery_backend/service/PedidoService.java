package com.deliveryapp.delivery_backend.service;

import com.deliveryapp.delivery_backend.model.*;
import com.deliveryapp.delivery_backend.repository.PedidoRepository;
import com.deliveryapp.delivery_backend.repository.ProductoRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.deliveryapp.delivery_backend.repository.UsuarioRepository;

@Service
public class PedidoService {

    @Autowired
    private PedidoRepository pedidoRepository;

    @Autowired
    private ProductoRepository productoRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    public Pedido crearPedido(PedidoRequest request) {
        Cliente cliente = (Cliente) usuarioRepository.findById(request.getClienteId())
                .orElseThrow(() -> new RuntimeException("Cliente no encontrado"));

        Restaurante restaurante = (Restaurante) usuarioRepository.findById(request.getRestauranteId())
                .orElseThrow(() -> new RuntimeException("Restaurante no encontrado"));

                Pedido pedido = new Pedido();
        pedido.setCliente(cliente);
        pedido.setRestaurante(restaurante);
        pedido.setLatitudEntrega(request.getLatitudEntrega());
        pedido.setLongitudEntrega(request.getLongitudEntrega());

        double totalCalculado = 0.0;

        for (PedidoRequest.ItemPedido item : request.getItems()) {
            Producto producto = productoRepository.findById(item.getProductoId())
                    .orElseThrow(() -> new RuntimeException("Producto no encontrado"));

            DetallePedido detalle = new DetallePedido();
            detalle.setPedido(pedido);
            detalle.setProducto(producto);
            detalle.setCantidad(item.getCantidad());
            double subtotal = producto.getPrecio() * item.getCantidad();
            detalle.setSubtotal(subtotal);

            pedido.getDetalles().add(detalle);
            totalCalculado += subtotal;
        }

        pedido.setTotal(totalCalculado);
        return pedidoRepository.save(pedido);
    }

    public List<Pedido> listarPorCliente(Long clienteId) {
        return pedidoRepository.findByClienteId(clienteId);
    }

    public Pedido actualizarEstado(Long pedidoId, String nuevoEstado) {
        Pedido pedido = pedidoRepository.findById(pedidoId)
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));
        pedido.setEstado(nuevoEstado);
        return pedidoRepository.save(pedido);
    }

    public Pedido asignarRepartidor(Long pedidoId, Long repartidorId) {
        Pedido pedido = pedidoRepository.findById(pedidoId)
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));

        Repartidor repartidor = (Repartidor) usuarioRepository.findById(repartidorId)
                .orElseThrow(() -> new RuntimeException("Repartidor no encontrado"));

        pedido.setRepartidor(repartidor);
        pedido.setEstado("EN_CAMINO");
        return pedidoRepository.save(pedido);
    }

    public Pedido buscarPorId(Long pedidoId) {
        return pedidoRepository.findById(pedidoId)
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));
    }

    public List<Pedido> listarPorRestaurante(Long restauranteId) {
        return pedidoRepository.findByRestauranteId(restauranteId);
    }

    public List<Pedido> listarPendientes() {
        return pedidoRepository.findByEstado("PENDIENTE");
    }
}