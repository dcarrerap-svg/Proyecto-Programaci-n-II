package com.deliveryapp.delivery_backend.controller;

import com.deliveryapp.delivery_backend.model.Pedido;
import com.deliveryapp.delivery_backend.model.PedidoRequest;
import com.deliveryapp.delivery_backend.service.PedidoService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/pedidos")
public class PedidoController {

    @Autowired
    private PedidoService pedidoService;

    @PostMapping
    public Pedido crear(@RequestBody PedidoRequest request) {
        return pedidoService.crearPedido(request);
    }

    @GetMapping("/cliente/{clienteId}")
    public List<Pedido> listarPorCliente(@PathVariable Long clienteId) {
        return pedidoService.listarPorCliente(clienteId);
    }

    @PutMapping("/{pedidoId}/estado")
    public Pedido actualizarEstado(@PathVariable Long pedidoId, @RequestBody String nuevoEstado) {
        return pedidoService.actualizarEstado(pedidoId, nuevoEstado.replace("\"", ""));
    }
        @PutMapping("/{pedidoId}/repartidor/{repartidorId}")
    public Pedido asignarRepartidor(@PathVariable Long pedidoId, @PathVariable Long repartidorId) {
        return pedidoService.asignarRepartidor(pedidoId, repartidorId);
    }
        @GetMapping("/{pedidoId}")
    public Pedido buscarPorId(@PathVariable Long pedidoId) {
        return pedidoService.buscarPorId(pedidoId);
    }
        @GetMapping("/pendientes")
    public List<Pedido> listarPendientes() {
        return pedidoService.listarPendientes();
    }
        @GetMapping("/restaurante/{restauranteId}")
    public List<Pedido> listarPorRestaurante(@PathVariable Long restauranteId) {
        return pedidoService.listarPorRestaurante(restauranteId);
    }
}
