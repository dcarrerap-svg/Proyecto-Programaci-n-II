package com.deliveryapp.delivery_backend.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@DiscriminatorValue("CLIENTE")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class Cliente extends Usuario {

    private String direccionFavorita;

    @Override
    public String obtenerPanel() {
        return "Panel de Cliente: explorar restaurantes, hacer pedidos, ver historial";
    }
}