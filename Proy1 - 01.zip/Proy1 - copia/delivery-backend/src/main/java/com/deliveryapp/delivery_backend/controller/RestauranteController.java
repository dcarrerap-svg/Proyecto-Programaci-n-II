package com.deliveryapp.delivery_backend.controller;

import com.deliveryapp.delivery_backend.model.Restaurante;
import com.deliveryapp.delivery_backend.service.UsuarioService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/restaurantes")
public class RestauranteController {

    @Autowired
    private UsuarioService usuarioService;

    @PostMapping("/registro")
    public Restaurante registrar(@RequestBody Restaurante restaurante) {
        return usuarioService.registrarRestaurante(restaurante);
    }

    @GetMapping
    public List<Restaurante> listar() {
        return usuarioService.listarRestaurantes();
    }
}