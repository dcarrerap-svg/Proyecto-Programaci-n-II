package com.deliveryapp.delivery_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeliveryBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
