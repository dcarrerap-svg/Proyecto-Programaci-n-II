# Parche del backend PideYa (para revisar y aplicar)

Cambios pequeños que resuelven las limitaciones de la app: guardar pago, envío y código de entrega,
aceptar o rechazar pedidos (comercio), pedidos por repartidor y calificación visible.
No se compiló aquí: **revisar y probar antes de usar**.

## Cómo aplicarlo
1. Copiar las carpetas `model`, `repository`, `service` y `controller` sobre
   `src/main/java/com/deliveryapp/delivery_backend/`, reemplazando los 6 archivos.
2. Reiniciar el servidor. Con `spring.jpa.hibernate.ddl-auto=update` Hibernate agrega solo las columnas nuevas.
3. Los pedidos viejos quedan sin código de entrega (se pueden entregar sin código).

## Archivos modificados
Pedido, PedidoRequest, PedidoRepository, PedidoService, PedidoController, CalificacionService.

## Ciclo de estados (se valida en el servidor)
PENDIENTE -> ACEPTADO o RECHAZADO (comercio) -> PREPARANDO -> LISTO (comercio)
-> EN_CAMINO (el repartidor toma el pedido) -> ENTREGADO (con el código de 4 dígitos).
También: CANCELADO desde PENDIENTE o ACEPTADO.

## Endpoints nuevos
| Método | Ruta | Para qué |
|---|---|---|
| PUT | /api/pedidos/{id}/aceptar | El comercio acepta |
| PUT | /api/pedidos/{id}/rechazar | El comercio rechaza |
| PUT | /api/pedidos/{id}/estado | PREPARANDO, LISTO, CANCELADO (valida transiciones) |
| GET | /api/pedidos/estado/{estado} | Ej. LISTO: pedidos que el repartidor puede tomar |
| GET | /api/pedidos/repartidor/{id} | Entregas de un repartidor |
| PUT | /api/pedidos/{id}/entregar | Confirma la entrega; el cuerpo es el código en texto |
| GET | /api/pedidos/{id}/codigo | El cliente consulta su código |

## Campos nuevos
- Pedido: metodoPago, costoEnvio, codigoEntrega (oculto en el JSON), calificacionEstrellas.
- POST /api/pedidos acepta además metodoPago y costoEnvio.

## Cambios que afectan a lo que ya funciona
- PUT /pedidos/{id}/estado ya no acepta ENTREGADO ni EN_CAMINO ni saltos de estado.
- Asignar repartidor solo funciona si el pedido está LISTO (antes bastaba PENDIENTE).
- Hay que actualizar la app y la web a este ciclo de estados.

## Limitación que sigue
No hay autenticación: cualquiera que conozca la URL puede llamar a /codigo.
Para protegerlo de verdad hacen falta login con token y roles.
