package com.deliveryapp.delivery_backend.repository;

import com.deliveryapp.delivery_backend.model.Pedido;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PedidoRepository extends JpaRepository<Pedido, Long> {

    List<Pedido> findByClienteId(Long clienteId);
    List<Pedido> findByRestauranteId(Long restauranteId);
    List<Pedido> findByEstado(String estado);
    List<Pedido> findByRepartidorId(Long repartidorId);
}