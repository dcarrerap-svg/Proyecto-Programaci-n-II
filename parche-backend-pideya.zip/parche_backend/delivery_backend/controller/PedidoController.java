package com.deliveryapp.delivery_backend.controller;

import com.deliveryapp.delivery_backend.model.Pedido;
import com.deliveryapp.delivery_backend.model.PedidoRequest;
import com.deliveryapp.delivery_backend.service.PedidoService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/pedidos")
public class PedidoController {

    @Autowired
    private PedidoService pedidoService;

    @PostMapping
    public Pedido crear(@RequestBody PedidoRequest request) {
        return pedidoService.crearPedido(request);
    }

    @GetMapping("/cliente/{clienteId}")
    public List<Pedido> listarPorCliente(@PathVariable Long clienteId) {
        return pedidoService.listarPorCliente(clienteId);
    }

    @PutMapping("/{pedidoId}/estado")
    public Pedido actualizarEstado(@PathVariable Long pedidoId, @RequestBody String nuevoEstado) {
        return pedidoService.actualizarEstado(pedidoId, nuevoEstado.replace("\"", ""));
    }
        @PutMapping("/{pedidoId}/repartidor/{repartidorId}")
    public Pedido asignarRepartidor(@PathVariable Long pedidoId, @PathVariable Long repartidorId) {
        return pedidoService.asignarRepartidor(pedidoId, repartidorId);
    }
        @GetMapping("/{pedidoId}")
    public Pedido buscarPorId(@PathVariable Long pedidoId) {
        return pedidoService.buscarPorId(pedidoId);
    }
        @GetMapping("/pendientes")
    public List<Pedido> listarPendientes() {
        return pedidoService.listarPendientes();
    }
        @GetMapping("/restaurante/{restauranteId}")
    public List<Pedido> listarPorRestaurante(@PathVariable Long restauranteId) {
        return pedidoService.listarPorRestaurante(restauranteId);
    }

    @PutMapping("/{pedidoId}/aceptar")
    public Pedido aceptar(@PathVariable Long pedidoId) {
        return pedidoService.actualizarEstado(pedidoId, "ACEPTADO");
    }

    @PutMapping("/{pedidoId}/rechazar")
    public Pedido rechazar(@PathVariable Long pedidoId) {
        return pedidoService.actualizarEstado(pedidoId, "RECHAZADO");
    }

    @PutMapping("/{pedidoId}/entregar")
    public Pedido entregar(@PathVariable Long pedidoId, @RequestBody String codigo) {
        return pedidoService.confirmarEntrega(pedidoId, codigo.replace("\"", "").trim());
    }

    @GetMapping("/{pedidoId}/codigo")
    public String codigo(@PathVariable Long pedidoId) {
        return pedidoService.obtenerCodigo(pedidoId);
    }

    @GetMapping("/estado/{estado}")
    public List<Pedido> listarPorEstado(@PathVariable String estado) {
        return pedidoService.listarPorEstado(estado);
    }

    @GetMapping("/repartidor/{repartidorId}")
    public List<Pedido> listarPorRepartidor(@PathVariable Long repartidorId) {
        return pedidoService.listarPorRepartidor(repartidorId);
    }
}
