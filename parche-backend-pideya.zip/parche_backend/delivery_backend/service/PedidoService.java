package com.deliveryapp.delivery_backend.service;

import com.deliveryapp.delivery_backend.model.*;
import com.deliveryapp.delivery_backend.repository.PedidoRepository;
import com.deliveryapp.delivery_backend.repository.ProductoRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.deliveryapp.delivery_backend.repository.UsuarioRepository;

@Service
public class PedidoService {

    @Autowired
    private PedidoRepository pedidoRepository;

    @Autowired
    private ProductoRepository productoRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    public Pedido crearPedido(PedidoRequest request) {
        Cliente cliente = (Cliente) usuarioRepository.findById(request.getClienteId())
                .orElseThrow(() -> new RuntimeException("Cliente no encontrado"));

        Restaurante restaurante = (Restaurante) usuarioRepository.findById(request.getRestauranteId())
                .orElseThrow(() -> new RuntimeException("Restaurante no encontrado"));

                Pedido pedido = new Pedido();
        pedido.setCliente(cliente);
        pedido.setRestaurante(restaurante);
        pedido.setLatitudEntrega(request.getLatitudEntrega());
        pedido.setLongitudEntrega(request.getLongitudEntrega());

        double totalCalculado = 0.0;

        for (PedidoRequest.ItemPedido item : request.getItems()) {
            Producto producto = productoRepository.findById(item.getProductoId())
                    .orElseThrow(() -> new RuntimeException("Producto no encontrado"));

            DetallePedido detalle = new DetallePedido();
            detalle.setPedido(pedido);
            detalle.setProducto(producto);
            detalle.setCantidad(item.getCantidad());
            double subtotal = producto.getPrecio() * item.getCantidad();
            detalle.setSubtotal(subtotal);

            pedido.getDetalles().add(detalle);
            totalCalculado += subtotal;
        }

        pedido.setMetodoPago(request.getMetodoPago() != null ? request.getMetodoPago() : "EFECTIVO");
        pedido.setCostoEnvio(request.getCostoEnvio() != null ? request.getCostoEnvio() : 0.0);
        pedido.setCodigoEntrega(String.format("%04d", new java.security.SecureRandom().nextInt(10000)));
        pedido.setTotal(totalCalculado);
        return pedidoRepository.save(pedido);
    }

    public List<Pedido> listarPorCliente(Long clienteId) {
        return pedidoRepository.findByClienteId(clienteId);
    }

    private static final java.util.Map<String, List<String>> TRANSICIONES = java.util.Map.of(
            "PENDIENTE", List.of("ACEPTADO", "RECHAZADO", "CANCELADO"),
            "ACEPTADO", List.of("PREPARANDO", "CANCELADO"),
            "PREPARANDO", List.of("LISTO"),
            "LISTO", List.of("EN_CAMINO"),
            "EN_CAMINO", List.of("ENTREGADO"));

    public Pedido actualizarEstado(Long pedidoId, String nuevoEstado) {
        Pedido pedido = buscarPorId(pedidoId);
        if ("ENTREGADO".equals(nuevoEstado)) {
            throw new RuntimeException("La entrega se confirma con el código: PUT /api/pedidos/{id}/entregar");
        }
        if ("EN_CAMINO".equals(nuevoEstado)) {
            throw new RuntimeException("Para pasar a EN_CAMINO se asigna un repartidor");
        }
        List<String> permitidos = TRANSICIONES.getOrDefault(pedido.getEstado(), List.of());
        if (!permitidos.contains(nuevoEstado)) {
            throw new RuntimeException("Transición no permitida: " + pedido.getEstado() + " -> " + nuevoEstado);
        }
        pedido.setEstado(nuevoEstado);
        return pedidoRepository.save(pedido);
    }

    public Pedido asignarRepartidor(Long pedidoId, Long repartidorId) {
        Pedido pedido = pedidoRepository.findById(pedidoId)
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));

        if (!"LISTO".equals(pedido.getEstado())) {
            throw new RuntimeException("El pedido aún no está listo para recoger");
        }

        Repartidor repartidor = (Repartidor) usuarioRepository.findById(repartidorId)
                .orElseThrow(() -> new RuntimeException("Repartidor no encontrado"));

        pedido.setRepartidor(repartidor);
        pedido.setEstado("EN_CAMINO");
        return pedidoRepository.save(pedido);
    }

    public Pedido buscarPorId(Long pedidoId) {
        return pedidoRepository.findById(pedidoId)
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));
    }

    public List<Pedido> listarPorRestaurante(Long restauranteId) {
        return pedidoRepository.findByRestauranteId(restauranteId);
    }

    public List<Pedido> listarPendientes() {
        return pedidoRepository.findByEstado("PENDIENTE");
    }

    public Pedido confirmarEntrega(Long pedidoId, String codigo) {
        Pedido pedido = buscarPorId(pedidoId);
        if (!"EN_CAMINO".equals(pedido.getEstado())) {
            throw new RuntimeException("El pedido no está en camino");
        }
        if (pedido.getCodigoEntrega() != null && !pedido.getCodigoEntrega().equals(codigo)) {
            throw new RuntimeException("Código de entrega incorrecto");
        }
        pedido.setEstado("ENTREGADO");
        return pedidoRepository.save(pedido);
    }

    public String obtenerCodigo(Long pedidoId) {
        return buscarPorId(pedidoId).getCodigoEntrega();
    }

    public List<Pedido> listarPorEstado(String estado) {
        return pedidoRepository.findByEstado(estado);
    }

    public List<Pedido> listarPorRepartidor(Long repartidorId) {
        return pedidoRepository.findByRepartidorId(repartidorId);
    }
}
