package com.deliveryapp.delivery_backend.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "pedidos")
@Data
@NoArgsConstructor
public class Pedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "cliente_id", nullable = false)
    private Cliente cliente;

    @ManyToOne
    @JoinColumn(name = "restaurante_id", nullable = false)
    private Restaurante restaurante;
    
    @ManyToOne
    @JoinColumn(name = "repartidor_id")
    private Repartidor repartidor;

    @Column(nullable = false)
    private String estado = "PENDIENTE";

    @Column(nullable = false)
    private Double total = 0.0;

    private Double latitudEntrega;
    private Double longitudEntrega;

    private String metodoPago = "EFECTIVO";

    private Double costoEnvio = 0.0;

    // Se oculta del JSON de los pedidos; el cliente lo consulta en GET /api/pedidos/{id}/codigo
    @com.fasterxml.jackson.annotation.JsonIgnore
    private String codigoEntrega;

    // null = aún no calificado
    private Integer calificacionEstrellas;

    @OneToMany(mappedBy = "pedido", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<DetallePedido> detalles = new ArrayList<>();
}