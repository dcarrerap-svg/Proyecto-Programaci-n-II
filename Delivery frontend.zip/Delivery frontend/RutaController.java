package com.deliveryapp.delivery_backend.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;


import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;

@CrossOrigin(origins = "*") // Permite peticiones desde cualquier lugar

@RestController
public class RutaController {

    private static final Logger logger = LoggerFactory.getLogger(RutaController.class);
    private final RestClient restClient;
    private final ObjectMapper mapper;

    public RutaController() {
        this.restClient = RestClient.create();
        this.mapper = new ObjectMapper();
    }

    @GetMapping("/api/rutas")
    public ResponseEntity<?> calcularRuta(
            @RequestParam double origenLat,
            @RequestParam double origenLon,
            @RequestParam double destinoLat,
            @RequestParam double destinoLon) {

        // 1. Validación de coordenadas
        if (!validaCoordenadas(origenLat, origenLon)
                || !validaCoordenadas(destinoLat, destinoLon)) {
            return ResponseEntity.badRequest().body(
                Map.of("error", "Las coordenadas no son válidas")
            );
        }

        try {
            // OSRM espera longitud,latitud en ese orden
            String coordenadas = String.format(
                java.util.Locale.US,
                "%.6f,%.6f;%.6f,%.6f",
                origenLon, origenLat, destinoLon, destinoLat
            );

            String url = "https://router.project-osrm.org/route/v1/driving/"
                    + coordenadas
                    + "?overview=full&geometries=geojson";

            logger.debug("Consultando OSRM: {}", url);

            String cuerpo = restClient.get()
                    .uri(url)
                    .retrieve()
                    .body(String.class);

            // 2. Parseo seguro del JSON
            JsonNode respuesta = mapper.readTree(cuerpo);

            if (respuesta == null
                    || !"Ok".equals(respuesta.path("code").asText())) {
                return ResponseEntity.status(HttpStatus.BAD_GATEWAY)
                        .body(Map.of(
                            "error", "El servicio de rutas no encontró un recorrido",
                            "respuestaExterna", respuesta == null
                                    ? "Sin respuesta"
                                    : respuesta.toString()
                        ));
            }

            JsonNode rutas = respuesta.path("routes");

            if (!rutas.isArray() || rutas.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_GATEWAY)
                        .body(Map.of("error", "No se encontró una ruta"));
            }

            JsonNode ruta = rutas.get(0);
            JsonNode geometria = ruta.path("geometry");

            double distanciaMetros = ruta.path("distance").asDouble();
            double duracionSegundos = ruta.path("duration").asDouble();

            return ResponseEntity.ok(Map.of(
                    "distanciaMetros", distanciaMetros,
                    "distanciaKm", distanciaMetros / 1000.0,
                    "duracionSegundos", duracionSegundos,
                    "geometria", geometria
            ));

        } catch (RestClientException e) {
            logger.error("Error de conexión con OSRM: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_GATEWAY)
                .body(Map.of(
                    "error", "No se pudo conectar con el servicio de rutas",
                    "detalle", e.getMessage() != null ? e.getMessage() : "Sin detalle disponible"
                ));
        } catch (Exception e) {
            // 3. Captura genérica para errores de parseo u otros
            logger.error("Error inesperado procesando la ruta", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Map.of(
                    "error", "Error interno al procesar la ruta",
                    "detalle", e.getMessage()
                ));
        }
    }

    private boolean validaCoordenadas(double lat, double lon) {
        return Double.isFinite(lat)
                && Double.isFinite(lon)
                && lat >= -90 && lat <= 90
                && lon >= -180 && lon <= 180;
    }
}