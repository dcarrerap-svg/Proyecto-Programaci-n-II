package com.deliveryapp.delivery_backend.controller;

import com.deliveryapp.delivery_backend.model.Producto;
import com.deliveryapp.delivery_backend.service.ProductoService;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/productos")
public class ProductoController {

    @Autowired
    private ProductoService productoService;

    @PostMapping
    public ResponseEntity<?> crear(@RequestBody Producto producto) {
    // Validar que el restaurante venga en el JSON
    if (producto.getRestaurante() == null || producto.getRestaurante().getId() == null) {
        return ResponseEntity.badRequest().body(Map.of("error", "El producto debe tener un restaurante asignado"));
    }
    
    // Opcional: Validar que el ID pertenezca a un Restaurante real en la BD
    // (Asumiendo que tienes un repositorio para buscarlo)
    // Usuario user = usuarioRepository.findById(producto.getRestaurante().getId()).orElse(null);
    // if (!(user instanceof Restaurante)) return ResponseEntity.badRequest().body(Map.of("error", "El ID no es de un restaurante"));

    Producto nuevo = productoService.crear(producto);
    return ResponseEntity.ok(nuevo);
}

    @GetMapping("/restaurante/{restauranteId}")
    public List<Producto> listarPorRestaurante(@PathVariable Long restauranteId) {
        return productoService.listarPorRestaurante(restauranteId);
    }
        @PutMapping("/{id}")
    public Producto actualizar(@PathVariable Long id, @RequestBody Producto producto) {
        return productoService.actualizar(id, producto);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        productoService.eliminar(id);
    }
}