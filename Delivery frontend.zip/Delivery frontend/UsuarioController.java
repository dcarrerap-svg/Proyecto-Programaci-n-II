package com.deliveryapp.delivery_backend.controller;

import com.deliveryapp.delivery_backend.model.Cliente;
import com.deliveryapp.delivery_backend.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.deliveryapp.delivery_backend.model.LoginRequest;
import com.deliveryapp.delivery_backend.model.LoginResponse;
import com.deliveryapp.delivery_backend.model.Usuario;

@RestController
@RequestMapping("/api/clientes")
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    @PostMapping("/registro")
    public Cliente registrar(@RequestBody Cliente cliente) {
        return usuarioService.registrarCliente(cliente);
    }
        @PostMapping("/login")
    public org.springframework.http.ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
        try {
            Usuario user = usuarioService.login(loginRequest.getEmail(), loginRequest.getPassword());
            if (user == null) {
                return org.springframework.http.ResponseEntity.status(401).body(java.util.Map.of("error", "Credenciales incorrectas"));
            }
            // Devolvemos el DTO en lugar de la entidad completa
            return org.springframework.http.ResponseEntity.ok(new LoginResponse(user));
        } catch (Exception e) {
            return org.springframework.http.ResponseEntity.status(500).body(java.util.Map.of("error", "Error en el servidor"));
        }
    }
}
