package com.pideya.app.model;

public class Usuario {
    private final int id;
    private final String nombre, email, tipoUsuario;

    public Usuario(int id, String nombre, String email, String tipoUsuario) {
        this.id = id; this.nombre = nombre; this.email = email; this.tipoUsuario = tipoUsuario;
    }
    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getEmail() { return email; }
    public String getTipoUsuario() { return tipoUsuario; }
}
