package com.pideya.app.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

/** Adaptador genérico: sirve para restaurantes, productos y pedidos. */
public class ListaAdapter<T> extends RecyclerView.Adapter<ListaAdapter.VH> {
    public interface Binder<T> { void bind(View vista, T item); }
    static class VH extends RecyclerView.ViewHolder { VH(View v) { super(v); } }

    private final List<T> datos; private final int layout; private final Binder<T> binder;

    public ListaAdapter(List<T> datos, int layout, Binder<T> binder) {
        this.datos = datos; this.layout = layout; this.binder = binder;
    }
    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p, int t) {
        return new VH(LayoutInflater.from(p.getContext()).inflate(layout, p, false));
    }
    @Override public void onBindViewHolder(@NonNull VH h, int i) { binder.bind(h.itemView, datos.get(i)); }
    @Override public int getItemCount() { return datos.size(); }
}
