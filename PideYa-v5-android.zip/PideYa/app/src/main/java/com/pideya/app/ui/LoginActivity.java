package com.pideya.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.pideya.app.R;
import com.pideya.app.data.Callback;
import com.pideya.app.data.Repo;
import com.pideya.app.model.Usuario;
import com.pideya.app.util.Sesion;

public class LoginActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_login);
        com.pideya.app.util.Ui.insets(this, findViewById(R.id.header), findViewById(R.id.scroll));
        com.pideya.app.util.Ui.entrada(findViewById(R.id.scroll));
        findViewById(R.id.irRegistro).setOnClickListener(v -> startActivity(new Intent(this, RegistroActivity.class)));
        EditText email = findViewById(R.id.email), pass = findViewById(R.id.pass);
        TextView error = findViewById(R.id.error);
        findViewById(R.id.btnLogin).setOnClickListener(v ->
            Repo.get().login(email.getText().toString().trim(), pass.getText().toString(), new Callback<Usuario>() {
                @Override public void onOk(Usuario u) {
                    Sesion.usuario = u;
                    startActivity(new Intent(LoginActivity.this, RestaurantesActivity.class));
                    finish();
                }
                @Override public void onError(String m) { error.setText(m); }
            }));
    }
}
