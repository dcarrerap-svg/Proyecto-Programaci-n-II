package com.pideya.app.data;

import com.pideya.app.model.*;
import java.util.List;

public interface DeliveryRepository {
    void login(String email, String password, Callback<Usuario> cb);
    void registrar(String nombre, String email, String password, String direccion, Callback<Usuario> cb);
    void getRestaurantes(Callback<List<Restaurante>> cb);
    void getMenu(int restauranteId, Callback<List<Producto>> cb);
    void crearPedido(Usuario u, Restaurante r, List<Producto> items, Callback<Pedido> cb);
    void getPedidos(int clienteId, Callback<List<Pedido>> cb);
    void avanzarEstado(int pedidoId, Callback<Pedido> cb);
}
