package com.pideya.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.pideya.app.R;
import com.pideya.app.data.Callback;
import com.pideya.app.data.Repo;
import com.pideya.app.model.Pedido;
import com.pideya.app.model.Producto;
import com.pideya.app.model.Restaurante;
import com.pideya.app.util.Sesion;
import com.pideya.app.util.Ui;
import java.util.ArrayList;
import java.util.List;

public class MenuActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_lista);
        Ui.insets(this, findViewById(R.id.header), findViewById(R.id.barra));
        Restaurante rest = Sesion.restaurante;
        ((TextView) findViewById(R.id.titulo)).setText(rest.getEmoji() + " " + rest.getNombre());
        ((TextView) findViewById(R.id.subtitulo)).setText(rest.getCategoria() + " · ★ " + rest.getRating() + " · " + rest.getMinutos() + " min");
        TextView resumen = findViewById(R.id.resumen);
        resumen.setText("Carrito vacío");
        Button btn = findViewById(R.id.boton);
        btn.setText("Pedir ahora");

        RecyclerView rv = findViewById(R.id.lista);
        rv.setLayoutManager(new LinearLayoutManager(this));
        List<Producto> menu = new ArrayList<>();
        ListaAdapter<Producto> ad = new ListaAdapter<>(menu, R.layout.item_producto, (v, p) -> {
            ((TextView) v.findViewById(R.id.emoji)).setText(p.getEmoji());
            ((TextView) v.findViewById(R.id.nombre)).setText(p.getNombre());
            ((TextView) v.findViewById(R.id.descripcion)).setText(p.getDescripcion());
            ((TextView) v.findViewById(R.id.precio)).setText(Ui.q(p.getPrecio()));
            v.findViewById(R.id.agregar).setOnClickListener(x -> {
                Sesion.carrito.add(p);
                double total = 0;
                for (Producto q : Sesion.carrito) total += q.getPrecio();
                resumen.setText(Sesion.carrito.size() + " productos · " + Ui.q(total));
                Ui.pulso(x); Ui.pulso(resumen);
            });
        });
        rv.setAdapter(ad);
        Repo.get().getMenu(rest.getId(), new Callback<List<Producto>>() {
            @Override public void onOk(List<Producto> l) { menu.addAll(l); ad.notifyDataSetChanged(); rv.scheduleLayoutAnimation(); }
            @Override public void onError(String m) { Toast.makeText(MenuActivity.this, m, Toast.LENGTH_SHORT).show(); }
        });
        btn.setOnClickListener(v ->
            Repo.get().crearPedido(Sesion.usuario, rest, Sesion.carrito, new Callback<Pedido>() {
                @Override public void onOk(Pedido p) {
                    Sesion.carrito.clear();
                    startActivity(new Intent(MenuActivity.this, PedidosActivity.class));
                    finish();
                }
                @Override public void onError(String m) { Toast.makeText(MenuActivity.this, m, Toast.LENGTH_SHORT).show(); }
            }));
    }
}
