package com.pideya.app.model;

public class Producto {
    private final int id, restauranteId;
    private final String nombre, descripcion, emoji;
    private final double precio;

    public Producto(int id, String nombre, String descripcion, double precio, int restauranteId, String emoji) {
        this.id = id; this.nombre = nombre; this.descripcion = descripcion;
        this.precio = precio; this.restauranteId = restauranteId; this.emoji = emoji;
    }
    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getDescripcion() { return descripcion; }
    public double getPrecio() { return precio; }
    public int getRestauranteId() { return restauranteId; }
    public String getEmoji() { return emoji; }
}
