package com.pideya.app.model;

public class Pedido {
    private final int id, clienteId;
    private final String restaurante;
    private final double total;
    private EstadoPedido estado = EstadoPedido.PENDIENTE;

    public Pedido(int id, int clienteId, String restaurante, double total) {
        this.id = id; this.clienteId = clienteId; this.restaurante = restaurante; this.total = total;
    }
    public int getId() { return id; }
    public int getClienteId() { return clienteId; }
    public String getRestaurante() { return restaurante; }
    public double getTotal() { return total; }
    public EstadoPedido getEstado() { return estado; }
    public void avanzar() { estado = estado.siguiente(); }

    @Override public String toString() {
        return "Pedido #" + id + " · " + restaurante + "\nQ" + String.format("%.2f", total) + " · " + estado;
    }
}
