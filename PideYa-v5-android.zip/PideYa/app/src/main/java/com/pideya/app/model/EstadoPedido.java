package com.pideya.app.model;

public enum EstadoPedido {
    PENDIENTE, EN_CAMINO, ENTREGADO;

    /** Controla las transiciones válidas; ENTREGADO es final. */
    public EstadoPedido siguiente() {
        switch (this) {
            case PENDIENTE: return EN_CAMINO;
            case EN_CAMINO: return ENTREGADO;
            default: throw new IllegalStateException("El pedido ya fue entregado.");
        }
    }
}
