package com.pideya.app.util;

import com.pideya.app.model.*;
import java.util.ArrayList;
import java.util.List;

public class Sesion {
    public static Usuario usuario;
    public static Restaurante restaurante;
    public static final List<Producto> carrito = new ArrayList<>();

    public static void cerrar() {
        usuario = null;
        restaurante = null;
        carrito.clear();
    }
}
