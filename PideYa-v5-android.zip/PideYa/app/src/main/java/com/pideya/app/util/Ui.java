package com.pideya.app.util;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.view.View;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import java.util.Locale;

public class Ui {
    public static String q(double v) { return String.format(Locale.US, "Q%.2f", v); }

    /** Evita que la barra de estado, la de navegación y el teclado tapen el contenido. */
    public static void insets(Activity a, View top, View bottom) {
        int t0 = top.getPaddingTop(), b0 = bottom.getPaddingBottom();
        ViewCompat.setOnApplyWindowInsetsListener(a.findViewById(android.R.id.content), (v, w) -> {
            Insets s = w.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.ime());
            top.setPadding(top.getPaddingLeft(), t0 + s.top, top.getPaddingRight(), top.getPaddingBottom());
            bottom.setPadding(bottom.getPaddingLeft(), bottom.getPaddingTop(), bottom.getPaddingRight(), b0 + s.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
    }

    /** Efecto "rebote" al tocar. */
    public static void pulso(View v) {
        v.animate().scaleX(1.2f).scaleY(1.2f).setDuration(90)
            .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(120)).start();
    }

    /** Aparece deslizando desde abajo. */
    public static void entrada(View v) {
        v.setAlpha(0f); v.setTranslationY(80f);
        v.animate().alpha(1f).translationY(0f).setDuration(450).start();
    }

    public static void alternarTema(Activity a) {
        boolean noche = (a.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        int modo = noche ? AppCompatDelegate.MODE_NIGHT_NO : AppCompatDelegate.MODE_NIGHT_YES;
        a.getSharedPreferences("pideya", Context.MODE_PRIVATE).edit().putInt("tema", modo).apply();
        AppCompatDelegate.setDefaultNightMode(modo);
    }

    public static void aplicarTemaGuardado(Context c) {
        AppCompatDelegate.setDefaultNightMode(c.getSharedPreferences("pideya", Context.MODE_PRIVATE)
                .getInt("tema", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM));
    }
}
