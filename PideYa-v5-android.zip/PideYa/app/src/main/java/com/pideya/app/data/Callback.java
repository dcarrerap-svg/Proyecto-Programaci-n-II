package com.pideya.app.data;

/** Respuesta asíncrona. Igual que usará Retrofit, así no hay que reescribir las pantallas. */
public interface Callback<T> {
    void onOk(T resultado);
    void onError(String mensaje);
}
