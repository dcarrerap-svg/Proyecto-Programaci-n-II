package com.pideya.app.data;

import com.pideya.app.model.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

/** Datos de prueba en memoria. Se reemplaza por ApiRepository cuando el backend esté listo. */
public class MockRepository implements DeliveryRepository {
    private final List<Restaurante> restaurantes = new ArrayList<>();
    private final List<Producto> productos = new ArrayList<>();
    private final List<Pedido> pedidos = new ArrayList<>();
    private int siguienteId = 1, siguienteUsuario = 2;
    private final Map<String, Usuario> usuarios = new HashMap<>();
    private final Map<String, String> claves = new HashMap<>();
    {
        usuarios.put("cliente@test.com", new Usuario(1, "Cliente Demo", "cliente@test.com", "cliente"));
        claves.put("cliente@test.com", "12345");
    }

    public MockRepository() {
        restaurantes.add(new Restaurante(1, "Pizza Roma", "Zona 4", "🍕", "Pizzas y pastas", 4.8, 25));
        restaurantes.add(new Restaurante(2, "Pollos Don Chepe", "Zona 10", "🍗", "Pollo frito", 4.6, 30));
        restaurantes.add(new Restaurante(3, "Café Central", "Zona 1", "☕", "Café y postres", 4.9, 15));
        restaurantes.add(new Restaurante(4, "Sushi Kai", "Zona 15", "🍣", "Sushi y asiática", 4.7, 35));
        productos.add(new Producto(1, "Pizza pepperoni", "Mozzarella, pepperoni y salsa de la casa", 65, 1, "🍕"));
        productos.add(new Producto(2, "Pasta alfredo", "Fettuccine con crema y parmesano", 48, 1, "🍝"));
        productos.add(new Producto(3, "Pollo frito (6 pzas)", "Crujiente, con guarnición", 55, 2, "🍗"));
        productos.add(new Producto(4, "Combo familiar", "12 piezas, papas y bebidas", 120, 2, "🍟"));
        productos.add(new Producto(5, "Capuchino", "Espresso con leche espumada", 22, 3, "☕"));
        productos.add(new Producto(6, "Pastel de chocolate", "Porción con cobertura de cacao", 30, 3, "🍰"));
        productos.add(new Producto(7, "Rollo California", "8 piezas con aguacate y cangrejo", 58, 4, "🍣"));
        productos.add(new Producto(8, "Ramen de cerdo", "Caldo miso, huevo y cebollín", 62, 4, "🍜"));
    }

    @Override public void login(String email, String password, Callback<Usuario> cb) {
        String k = email.toLowerCase();
        if (usuarios.containsKey(k) && claves.get(k).equals(password)) cb.onOk(usuarios.get(k));
        else cb.onError("Correo o contraseña incorrectos.");
    }

    @Override public void registrar(String nombre, String email, String password, String direccion, Callback<Usuario> cb) {
        String k = email.toLowerCase();
        if (usuarios.containsKey(k)) { cb.onError("Ese correo ya está registrado."); return; } // igual que el backend
        Usuario u = new Usuario(siguienteUsuario++, nombre, email, "cliente");
        usuarios.put(k, u);
        claves.put(k, password);
        cb.onOk(u);
    }

    @Override public void getRestaurantes(Callback<List<Restaurante>> cb) { cb.onOk(restaurantes); }

    @Override public void getMenu(int restauranteId, Callback<List<Producto>> cb) {
        List<Producto> menu = new ArrayList<>();
        for (Producto p : productos) if (p.getRestauranteId() == restauranteId) menu.add(p);
        cb.onOk(menu);
    }

    @Override public void crearPedido(Usuario u, Restaurante r, List<Producto> items, Callback<Pedido> cb) {
        if (items.isEmpty()) { cb.onError("El carrito está vacío."); return; }
        double total = 0;
        for (Producto p : items) total += p.getPrecio(); // el total se calcula aquí, como en el backend
        Pedido pedido = new Pedido(siguienteId++, u.getId(), r.getNombre(), total);
        pedidos.add(0, pedido);
        cb.onOk(pedido);
    }

    @Override public void getPedidos(int clienteId, Callback<List<Pedido>> cb) {
        List<Pedido> propios = new ArrayList<>();
        for (Pedido p : pedidos) if (p.getClienteId() == clienteId) propios.add(p);
        cb.onOk(propios);
    }

    @Override public void avanzarEstado(int pedidoId, Callback<Pedido> cb) {
        for (Pedido p : pedidos) {
            if (p.getId() == pedidoId) {
                try { p.avanzar(); cb.onOk(p); }
                catch (IllegalStateException e) { cb.onError(e.getMessage()); }
                return;
            }
        }
        cb.onError("Pedido no encontrado.");
    }
}
