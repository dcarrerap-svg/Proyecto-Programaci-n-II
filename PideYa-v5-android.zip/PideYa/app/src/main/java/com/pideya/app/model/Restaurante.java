package com.pideya.app.model;

public class Restaurante {
    private final int id, minutos;
    private final String nombre, direccion, emoji, categoria;
    private final double rating;

    public Restaurante(int id, String nombre, String direccion, String emoji, String categoria, double rating, int minutos) {
        this.id = id; this.nombre = nombre; this.direccion = direccion;
        this.emoji = emoji; this.categoria = categoria; this.rating = rating; this.minutos = minutos;
    }
    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getDireccion() { return direccion; }
    public String getEmoji() { return emoji; }
    public String getCategoria() { return categoria; }
    public double getRating() { return rating; }
    public int getMinutos() { return minutos; }
}
