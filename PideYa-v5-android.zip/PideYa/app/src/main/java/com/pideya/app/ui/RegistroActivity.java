package com.pideya.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.pideya.app.R;
import com.pideya.app.data.Callback;
import com.pideya.app.data.Repo;
import com.pideya.app.model.Usuario;
import com.pideya.app.util.Sesion;
import com.pideya.app.util.Ui;

public class RegistroActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_registro);
        Ui.insets(this, findViewById(R.id.header), findViewById(R.id.scroll));
        Ui.entrada(findViewById(R.id.scroll));
        EditText nombre = findViewById(R.id.nombre), email = findViewById(R.id.email),
                 pass = findViewById(R.id.pass), dir = findViewById(R.id.direccion);
        TextView error = findViewById(R.id.error);
        findViewById(R.id.irLogin).setOnClickListener(v -> finish());
        findViewById(R.id.btnRegistro).setOnClickListener(v -> {
            String n = nombre.getText().toString().trim(), c = email.getText().toString().trim();
            String p = pass.getText().toString(), d = dir.getText().toString().trim();
            if (n.isEmpty() || c.isEmpty() || p.isEmpty()) { error.setText("Completa nombre, correo y contraseña."); return; }
            if (!Patterns.EMAIL_ADDRESS.matcher(c).matches()) { error.setText("El correo no es válido."); return; }
            if (p.length() < 5) { error.setText("La contraseña debe tener al menos 5 caracteres."); return; }
            Repo.get().registrar(n, c, p, d, new Callback<Usuario>() {
                @Override public void onOk(Usuario u) {
                    Sesion.usuario = u;
                    startActivity(new Intent(RegistroActivity.this, RestaurantesActivity.class));
                    finishAffinity();
                }
                @Override public void onError(String m) { error.setText(m); }
            });
        });
    }
}
