package com.pideya.app.data;

/** ÚNICO punto a cambiar para conectar al backend: new MockRepository() -> new ApiRepository(). */
public class Repo {
    private static final DeliveryRepository INSTANCIA = new MockRepository();
    public static DeliveryRepository get() { return INSTANCIA; }
}
