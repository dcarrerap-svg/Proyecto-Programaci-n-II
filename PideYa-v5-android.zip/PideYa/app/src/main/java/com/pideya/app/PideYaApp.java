package com.pideya.app;

import android.app.Application;
import com.pideya.app.util.Ui;

public class PideYaApp extends Application {
    @Override public void onCreate() {
        super.onCreate();
        Ui.aplicarTemaGuardado(this);
    }
}
