package com.pideya.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.pideya.app.R;
import com.pideya.app.data.Callback;
import com.pideya.app.data.Repo;
import com.pideya.app.model.EstadoPedido;
import com.pideya.app.model.Pedido;
import com.pideya.app.util.Sesion;
import com.pideya.app.util.Ui;
import java.util.ArrayList;
import java.util.List;

public class PedidosActivity extends AppCompatActivity {
    private static String texto(EstadoPedido e) {
        switch (e) {
            case PENDIENTE: return "⏳ Preparando";
            case EN_CAMINO: return "🛵 En camino";
            default: return "✅ Entregado";
        }
    }
    private static int color(EstadoPedido e) {
        switch (e) {
            case PENDIENTE: return 0xFFFFC93C;
            case EN_CAMINO: return 0xFFFF7A3D;
            default: return 0xFF8CD867;
        }
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_lista);
        Ui.insets(this, findViewById(R.id.header), findViewById(R.id.barra));
        ((TextView) findViewById(R.id.titulo)).setText("Mis pedidos");
        ((TextView) findViewById(R.id.subtitulo)).setText("Toca un pedido para simular su avance (demo)");
        ((TextView) findViewById(R.id.resumen)).setText("¿Se te antoja algo más?");
        Button btn = findViewById(R.id.boton);
        btn.setText("Ver restaurantes");
        btn.setOnClickListener(v -> {
            startActivity(new Intent(this, RestaurantesActivity.class));
            finish();
        });

        RecyclerView rv = findViewById(R.id.lista);
        rv.setLayoutManager(new LinearLayoutManager(this));
        TextView vacio = findViewById(R.id.vacio);
        List<Pedido> datos = new ArrayList<>();
        ListaAdapter<Pedido> ad = new ListaAdapter<>(datos, R.layout.item_pedido, (v, p) -> {
            ((TextView) v.findViewById(R.id.numero)).setText("Pedido #" + p.getId());
            ((TextView) v.findViewById(R.id.restaurante)).setText(p.getRestaurante());
            ((TextView) v.findViewById(R.id.total)).setText(Ui.q(p.getTotal()));
            TextView chip = v.findViewById(R.id.estado);
            chip.setText(texto(p.getEstado()));
            chip.getBackground().mutate().setTint(color(p.getEstado()));
            Pedido ref = p;
            v.setOnClickListener(x -> Repo.get().avanzarEstado(ref.getId(), new Callback<Pedido>() {
                @Override public void onOk(Pedido r) { rvRefrescar(rv); }
                @Override public void onError(String m) { Toast.makeText(PedidosActivity.this, m, Toast.LENGTH_SHORT).show(); }
            }));
        });
        rv.setAdapter(ad);
        Repo.get().getPedidos(Sesion.usuario.getId(), new Callback<List<Pedido>>() {
            @Override public void onOk(List<Pedido> l) {
                datos.addAll(l);
                ad.notifyDataSetChanged();
                rv.scheduleLayoutAnimation();
                vacio.setVisibility(datos.isEmpty() ? View.VISIBLE : View.GONE);
            }
            @Override public void onError(String m) { Toast.makeText(PedidosActivity.this, m, Toast.LENGTH_SHORT).show(); }
        });
    }

    private void rvRefrescar(RecyclerView rv) { rv.getAdapter().notifyDataSetChanged(); }
}
